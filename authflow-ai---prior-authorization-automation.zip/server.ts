import express from 'express';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;
if (apiKey) {
  aiClient = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    geminiConfigured: !!apiKey,
    timestamp: new Date().toISOString(),
  });
});

// 1. AI Clinical Extraction Endpoint
app.post('/api/prior-auth/extract', async (req, res) => {
  try {
    const { clinicalNote, targetPayer, serviceType } = req.body;

    if (!clinicalNote || typeof clinicalNote !== 'string') {
      return res.status(400).json({ error: 'clinicalNote is required.' });
    }

    if (!aiClient) {
      return res.status(503).json({
        error: 'Gemini API is not configured on the server. Please check GEMINI_API_KEY in secrets.',
      });
    }

    const systemPrompt = `You are a certified Clinical Documentation Integrity (CDI) specialist and Prior Authorization Medical Director.
Your task is to analyze unstructured clinical EHR notes, discharge summaries, imaging reports, and provider consults to extract structured prior authorization data for submission to insurance payers (e.g., UnitedHealthcare, Aetna, Cigna, Anthem BCBS, Humana, Medicare Advantage).

Follow clinical guidelines (InterQual / Milliman Care Guidelines (MCG)) strictly.
Determine:
1. Patient demographic and insurance policy identification
2. Primary & secondary ICD-10-CM diagnosis codes (with official descriptions)
3. Requested CPT / HCPCS procedure or medication codes with units and setting
4. Objective clinical evidence (prior conservative care failures with exact durations, diagnostic/imaging findings, functional impairments)
5. InterQual / MCG criteria checklist breakdown (each required clinical criterion, whether it is met, and the exact supporting quote from the clinical text)
6. Denial Risk Analysis (calculate probability % of initial payer denial based on clinical gaps)
7. Full Electronic EDI 278 / CMS-1500 form fields mapped
8. A professional Letter of Medical Necessity draft ready for physician sign-off.

Format your output strictly according to the specified JSON schema.`;

    const extractionPrompt = `Target Insurance Payer: ${targetPayer || 'UnitedHealthcare'}
Requested Service Type / Category: ${serviceType || 'Not specified - infer from notes'}

CLINICAL EHR NOTE:
---
${clinicalNote}
---

Extract all prior authorization parameters and evaluate clinical necessity against ${targetPayer || 'standard commercial'} medical review criteria.`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: extractionPrompt,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            patient: {
              type: Type.OBJECT,
              properties: {
                fullName: { type: Type.STRING },
                dob: { type: Type.STRING },
                gender: { type: Type.STRING },
                memberId: { type: Type.STRING },
                groupNumber: { type: Type.STRING },
                payerName: { type: Type.STRING },
                orderingProvider: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    npi: { type: Type.STRING },
                    specialty: { type: Type.STRING },
                    facilityName: { type: Type.STRING },
                    contactPhone: { type: Type.STRING },
                    faxNumber: { type: Type.STRING },
                  },
                  required: ['name', 'npi', 'specialty'],
                },
              },
              required: ['fullName', 'dob', 'memberId', 'payerName', 'orderingProvider'],
            },
            clinical: {
              type: Type.OBJECT,
              properties: {
                primaryDiagnosis: {
                  type: Type.OBJECT,
                  properties: {
                    code: { type: Type.STRING },
                    description: { type: Type.STRING },
                  },
                  required: ['code', 'description'],
                },
                secondaryDiagnoses: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      code: { type: Type.STRING },
                      description: { type: Type.STRING },
                    },
                    required: ['code', 'description'],
                  },
                },
                requestedService: {
                  type: Type.OBJECT,
                  properties: {
                    serviceName: { type: Type.STRING },
                    cptCode: { type: Type.STRING },
                    hcpcsCode: { type: Type.STRING },
                    ndcCode: { type: Type.STRING },
                    units: { type: Type.NUMBER },
                    serviceSetting: { type: Type.STRING },
                    urgency: { type: Type.STRING },
                    anticipatedDate: { type: Type.STRING },
                  },
                  required: ['serviceName', 'cptCode', 'units', 'serviceSetting', 'urgency'],
                },
                conservativeTherapies: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      treatment: { type: Type.STRING },
                      duration: { type: Type.STRING },
                      outcome: { type: Type.STRING },
                      documentedDate: { type: Type.STRING },
                    },
                    required: ['treatment', 'duration', 'outcome'],
                  },
                },
                diagnosticFindings: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      testType: { type: Type.STRING },
                      date: { type: Type.STRING },
                      finding: { type: Type.STRING },
                      satisfiesCriteria: { type: Type.BOOLEAN },
                    },
                    required: ['testType', 'finding', 'satisfiesCriteria'],
                  },
                },
                contraindications: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                functionalImpairmentSummary: { type: Type.STRING },
              },
              required: ['primaryDiagnosis', 'requestedService', 'conservativeTherapies', 'diagnosticFindings', 'functionalImpairmentSummary'],
            },
            guidelineReview: {
              type: Type.OBJECT,
              properties: {
                guidelineName: { type: Type.STRING },
                allCriteriaMet: { type: Type.BOOLEAN },
                approvalConfidenceScore: { type: Type.NUMBER, description: 'Score between 0 and 100' },
                denialRiskPercentage: { type: Type.NUMBER, description: 'Percentage risk between 0 and 100' },
                denialRiskFactors: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                clinicalChecklist: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      criterionTitle: { type: Type.STRING },
                      isMet: { type: Type.BOOLEAN },
                      evidenceQuote: { type: Type.STRING },
                      deficiencyRemediation: { type: Type.STRING },
                    },
                    required: ['criterionTitle', 'isMet', 'evidenceQuote'],
                  },
                },
              },
              required: ['guidelineName', 'allCriteriaMet', 'approvalConfidenceScore', 'denialRiskPercentage', 'clinicalChecklist'],
            },
            payerFormFields: {
              type: Type.OBJECT,
              properties: {
                box1_payerName: { type: Type.STRING },
                box2_patientName: { type: Type.STRING },
                box3_patientDob: { type: Type.STRING },
                box4_insuredId: { type: Type.STRING },
                box5_groupNumber: { type: Type.STRING },
                box14_dateOfCurrentIllness: { type: Type.STRING },
                box21_diagnosisCodes: { type: Type.STRING },
                box24_cptCodesWithModifiers: { type: Type.STRING },
                box24_placeOfService: { type: Type.STRING },
                box24_chargesEstimated: { type: Type.STRING },
                box25_federalTaxId: { type: Type.STRING },
                box31_physicianSignatureDate: { type: Type.STRING },
                box32_serviceFacilityLocation: { type: Type.STRING },
                box33_billingProviderInfo: { type: Type.STRING },
              },
              required: ['box1_payerName', 'box2_patientName', 'box4_insuredId', 'box21_diagnosisCodes', 'box24_cptCodesWithModifiers'],
            },
            medicalNecessityLetter: { type: Type.STRING },
          },
          required: ['patient', 'clinical', 'guidelineReview', 'payerFormFields', 'medicalNecessityLetter'],
        },
      },
    });

    const parsedData = JSON.parse(response.text || '{}');
    return res.json({ success: true, data: parsedData });
  } catch (error: any) {
    console.error('Error during clinical extraction:', error);
    return res.status(500).json({
      error: 'Failed to process clinical note with Gemini.',
      details: error.message || String(error),
    });
  }
});

// 2. AI Appeal Dossier Generation Endpoint
app.post('/api/prior-auth/appeal', async (req, res) => {
  try {
    const { paRecord, denialReason, denialCode, additionalEvidence } = req.body;

    if (!aiClient) {
      return res.status(503).json({
        error: 'Gemini API is not configured on the server.',
      });
    }

    const prompt = `You are a Senior Healthcare Attorney and Physician Medical Director specializing in Prior Authorization Appeals and Denial Overturns.
A commercial insurance payer has denied prior authorization for a patient.
Your objective is to generate an aggressive, authoritative, peer-reviewed Appeal Dossier and Letter of Reconsideration citing relevant Medicare National Coverage Determinations (NCD/LCD), InterQual/MCG guidelines, and randomized clinical trial literature.

DENIAL DETAILS:
Payer: ${paRecord?.patient?.payerName || 'UnitedHealthcare'}
Patient: ${paRecord?.patient?.fullName || 'Patient'}
Requested Procedure / Drug: ${paRecord?.clinical?.requestedService?.serviceName} (CPT: ${paRecord?.clinical?.requestedService?.cptCode})
Diagnosis: ${paRecord?.clinical?.primaryDiagnosis?.code} - ${paRecord?.clinical?.primaryDiagnosis?.description}
Denial Code: ${denialCode || 'CARC 197 / RARC N382 (Pre-certification/prior authorization required/lacking)'}
Payer Denial Justification: ${denialReason || 'Clinical documentation does not meet payer medical policy criteria for conservative therapy duration.'}
Additional Clinical Evidence / Counter-arguments: ${additionalEvidence || 'Provider attests conservative measures are exhausted and surgical delay risks irreversible neurological deficit.'}

Provide a JSON response with:
1. "appealLetter": Full formal letter addressed to Payer Appeals Committee with legal/regulatory notice under ERISA § 503 and CMS 42 CFR § 422.568.
2. "clinicalCounterpoints": Array of 3 to 5 bulleted counterarguments refuting the payer's medical director.
3. "literatureCitations": Array of 2 to 3 relevant peer-reviewed journal citations (NEJM, JAMA, Spine, JCO, etc.) with DOI and clinical takeaway.
4. "overturnProbabilityScore": Number between 0 and 100 estimated likelihood of overturn on Level 1 appeal.`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            appealLetter: { type: Type.STRING },
            clinicalCounterpoints: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            literatureCitations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  journal: { type: Type.STRING },
                  clinicalTakeaway: { type: Type.STRING },
                },
                required: ['title', 'journal', 'clinicalTakeaway'],
              },
            },
            overturnProbabilityScore: { type: Type.NUMBER },
          },
          required: ['appealLetter', 'clinicalCounterpoints', 'literatureCitations', 'overturnProbabilityScore'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ success: true, data: parsed });
  } catch (error: any) {
    console.error('Error generating appeal:', error);
    return res.status(500).json({ error: error.message || 'Failed to generate appeal dossier.' });
  }
});

// 3. AI Peer-to-Peer Physician Briefing Endpoint
app.post('/api/prior-auth/peer-to-peer', async (req, res) => {
  try {
    const { paRecord, denialReason } = req.body;

    if (!aiClient) {
      return res.status(503).json({ error: 'Gemini API not configured.' });
    }

    const prompt = `You are a Chief Medical Officer preparing an attending surgeon for an upcoming 5-minute Peer-to-Peer telephone review with an Insurance Medical Director.
Case Details:
Patient: ${paRecord?.patient?.fullName}, ${paRecord?.patient?.dob}
Procedure: ${paRecord?.clinical?.requestedService?.serviceName} (${paRecord?.clinical?.requestedService?.cptCode})
Diagnosis: ${paRecord?.clinical?.primaryDiagnosis?.code} - ${paRecord?.clinical?.primaryDiagnosis?.description}
Payer: ${paRecord?.patient?.payerName}
Denial Reason: ${denialReason}

Provide:
1. 30-Second Elevator Pitch
2. Objective Data Trap (the exact MRI/lab values that force approval under payer policy)
3. Direct Responses to the 3 most common Medical Director pushback questions
4. Closing demand statement for verbal immediate authorization number.`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            elevatorPitch: { type: Type.STRING },
            objectiveDataHighlights: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
            },
            rebuttals: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  payerQuestion: { type: Type.STRING },
                  recommendedAnswer: { type: Type.STRING },
                },
                required: ['payerQuestion', 'recommendedAnswer'],
              },
            },
            closingDemandScript: { type: Type.STRING },
          },
          required: ['elevatorPitch', 'objectiveDataHighlights', 'rebuttals', 'closingDemandScript'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({ success: true, data: parsed });
  } catch (error: any) {
    console.error('Error generating peer-to-peer script:', error);
    return res.status(500).json({ error: error.message || 'Failed to generate peer-to-peer brief.' });
  }
});

// Setup Vite or static serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AuthFlow AI Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
