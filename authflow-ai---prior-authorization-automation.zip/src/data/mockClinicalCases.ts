import { PriorAuthRecord } from '../types/priorAuth';

export interface SampleClinicalScenario {
  id: string;
  title: string;
  category: string;
  payer: string;
  service: string;
  cpt: string;
  urgency: 'Standard (5-10 Days)' | 'Urgent / Expedited (72 Hours)';
  patientName: string;
  ehrNoteText: string;
}

export const SAMPLE_EHR_SCENARIOS: SampleClinicalScenario[] = [
  {
    id: 'case-spine-01',
    title: 'Lumbar Spinal Stenosis - L4-L5 Microdiscectomy',
    category: 'Orthopedic / Spine Surgery',
    payer: 'UnitedHealthcare',
    service: 'Lumbar Laminotomy & Microdiscectomy L4-L5',
    cpt: '63030',
    urgency: 'Standard (5-10 Days)',
    patientName: 'Robert Henderson',
    ehrNoteText: `NEUROSURGICAL CONSULTATION & CLINICAL NOTE
Patient: Robert Henderson | DOB: 05/14/1962 (Age 64) | Gender: M
MRN: 8092147 | Insurance: UnitedHealthcare Choice Plus | Member ID: UHC90448102-01 | Group: 712904
Ordering Provider: Dr. Arthur Sterling, MD, FAANS (NPI: 1487692014) - Spine Institute of New England
Facility: Boston Memorial Hospital Ambulatory Surgery Pavilion (NPI: 1023194820)
Date of Encounter: September 22, 2026

CHIEF COMPLAINT:
Severe intractable right lower extremity radiculopathy and neurogenic claudication extending into the L5 dermatome, refractory to extensive conservative management.

HISTORY OF PRESENT ILLNESS:
Mr. Henderson is a 64-year-old active male presenting with 7 months of progressively disabling low back pain with prominent right lower extremity radiating pain down the posterolateral thigh, calf, and dorsum of the right foot. Walking tolerance is severely restricted to <50 yards before unbearable cramping and numbness force him to sit or stoop forward. Numerical pain rating 8/10 on right leg. Oswestry Disability Index (ODI) score is 58% (severe functional disability).

DOCUMENTED CONSERVATIVE THERAPY RECORD:
1. Physical Therapy: Completed 8 consecutive weeks of formal outpatient physical therapy (focusing on lumbar stabilization, flexion-based McKenzie exercises, and core strengthening) at BayState Rehabilitation between June 2, 2026 and July 28, 2026 (24 attended sessions). Symptoms persisted without significant functional improvement.
2. Pharmacotherapy: Trial of oral Meloxicam 15mg daily for 6 weeks, followed by Gabapentin titrated to 600mg TID over 8 weeks. Discontinued Meloxicam due to gastritis; Gabapentin yielded minimal relief (<15% pain reduction).
3. Interventional Injections: Fluoroscopically-guided right L4-L5 transforaminal epidural steroid injection (ESI) performed by Dr. Patel on August 11, 2026. Provided only 4 days of transient 30% relief followed by rebound radicular agony.

PHYSICAL EXAMINATION:
- Lumbar Spine: Tenderness over L4-L5 interspinous ligament. Pain exacerbated with lumbar extension and lateral rotation.
- Neurological: Right extensor hallucis longus (EHL) weakness 4/5; right tibialis anterior 4+/5. Decreased sensation to light touch and pinprick over right L5 dermatome.
- Provocative Tests: Right Straight Leg Raise (SLR) positive at 35 degrees with radicular reproduction to great toe. Left SLR negative.

DIAGNOSTIC IMAGING REVIEW:
Lumbar Spine MRI (Without contrast, performed at Boston Advanced Imaging on August 28, 2026):
1. L4-L5: Marked disc space narrowing with right paracentral/subarticular disc extrusion measuring 6.2 mm, causing severe right L5 traversing nerve root impingement and severe central canal stenosis (AP thecal sac diameter reduced to 5.4 mm; normal >10 mm).
2. Hypertrophy of the ligamentum flavum and facet arthropathy contributing to severe lateral recess narrowing.
3. No spondylolisthesis or dynamic instability noted on flexion/extension lumbar radiographs.

ASSESSMENT & PLAN:
1. Diagnosis: M48.061 - Spinal stenosis, lumbar region without neurogenic claudication; M54.16 - Radiculopathy, lumbar region; M51.26 - Other intervertebral disc displacement, lumbar region.
2. Recommendation: Right L4-L5 unilateral hemilaminotomy, partial facetectomy, and microdiscectomy with decompression of L5 nerve root (CPT 63030).
3. Medical Necessity: Patient has exhausted >6 weeks of supervised physical therapy, anti-inflammatory medications, and targeted fluoroscopic epidural steroid injections. Neurological examination reveals persistent motor deficit (EHL 4/5) correlating anatomically with severe L4-L5 right paracentral disc extrusion on MRI. Criteria under InterQual / UnitedHealthcare Commercial Medical Policy for Lumbar Spine Surgery are fully met. Delaying surgical decompression risks irreversible neurological injury and permanent drop foot.`,
  },
  {
    id: 'case-onco-02',
    title: 'HER2+ Metastatic Breast Cancer - Dual Biologic Infusion',
    category: 'Oncology / Specialty Infusion',
    payer: 'Aetna',
    service: 'Trastuzumab (J9355) + Pertuzumab (J9306) Infusion',
    cpt: '96413',
    urgency: 'Urgent / Expedited (72 Hours)',
    patientName: 'Elena Rostova',
    ehrNoteText: `ONCOLOGY COMPREHENSIVE CLINICAL NOTE
Patient: Elena Rostova | DOB: 11/03/1975 (Age 50) | Gender: F
MRN: 4410928 | Insurance: Aetna Choice POS II | Member ID: W984120938 | Group: 0882190
Ordering Provider: Dr. Maya Lin, MD, PhD (NPI: 1932084711) - Department of Medical Oncology
Facility: Memorial Cancer Pavilion Infusion Suite (NPI: 1841290382)
Date of Encounter: September 24, 2026

DIAGNOSIS & CLINICAL SUMMARY:
C50.911 - Malignant neoplasm of unsp site of right female breast; C79.51 - Secondary malignant neoplasm of bone.
Histopathology: Invasive Ductal Carcinoma (Grade 3), ER positive (40%), PR negative, HER2/neu positive (3+ by immunohistochemistry, confirmed by FISH amplification with HER2:CEP17 ratio of 4.2).

TREATMENT REQUEST:
Dual targeted HER2 monoclonal antibody therapy:
1. Pertuzumab (Perjeta) IV infusion (HCPCS J9306): Loading dose 840 mg IV, followed by 420 mg IV every 3 weeks.
2. Trastuzumab (Herceptin) IV infusion (HCPCS J9355): Loading dose 8 mg/kg IV, followed by 6 mg/kg IV every 3 weeks.
Administered with Docetaxel 75 mg/m2 every 21 days (CLEOPATRA trial regimen).
CPT Administration Code: 96413 (Chemotherapy administration, intravenous infusion technique; up to 1 hour, single or initial substance).

PRIOR ASSESSMENTS & CARDIAC MONITORING:
1. Baseline Transthoracic Echocardiogram (Echo) performed September 18, 2026: Normal left ventricular systolic function with Left Ventricular Ejection Fraction (LVEF) of 62%. No wall motion abnormalities. Meets safety criteria (>50% LVEF required for HER2 targeted therapy).
2. PET-CT whole body scan (September 15, 2026): Demonstrates hypermetabolic 3.4 cm right breast primary tumor with right axillary lymphadenopathy (SUV 8.6) and isolated hypermetabolic osteolytic metastasis in L2 vertebral body (SUV 5.8). No visceral liver or lung metastases.
3. Performance Status: ECOG Performance Status 1.
4. Laboratory: Creatinine 0.82 mg/dL, AST 24 U/L, ALT 28 U/L, ANC 4,200/uL, Platelets 240,000/uL.

CLINICAL JUSTIFICATION & NCCN COMPLIANCE:
First-line systemic therapy for HER2-positive metastatic breast cancer according to NCCN Category 1 Guidelines and CLEOPATRA trial landmark data. Urgent expedited review (72h) requested due to active metastatic bony involvement and rapid symptom proliferation. Delay in therapy initiation directly compromises progression-free survival.`,
  },
  {
    id: 'case-cardio-03',
    title: 'Severe Symptomatic Aortic Stenosis - TAVR',
    category: 'Cardiovascular / Structural Heart',
    payer: 'Anthem Blue Cross',
    service: 'Transcatheter Aortic Valve Replacement (TAVR)',
    cpt: '33361',
    urgency: 'Standard (5-10 Days)',
    patientName: 'Marcus Vance',
    ehrNoteText: `MULTIDISCIPLINARY HEART TEAM CONSULTATION
Patient: Marcus Vance | DOB: 08/19/1944 (Age 82) | Gender: M
MRN: 7109284 | Insurance: Anthem Blue Cross Medicare Advantage | Member ID: BCBS-88391024 | Group: ANT-401
Ordering Provider: Dr. Cameron Wells, MD, FACC (NPI: 1679041288) - Structural Heart Center
Facility: St. Jude Heart & Vascular Hospital (NPI: 1492019485)
Date of Encounter: September 21, 2026

CLINICAL PRESENTATION:
Mr. Vance is an 82-year-old male with symptomatic severe calcific aortic valve stenosis presenting with progressive New York Heart Association (NYHA) Class III dyspnea on minimal exertion, lower extremity edema, and two recent syncopal episodes while climbing stairs.

HEART TEAM EVALUATION & IMAGING FINDINGS:
1. Transthoracic & Transesophageal Echocardiogram (September 14, 2026):
   - Aortic Valve Area (AVA): 0.62 cm² (Index: 0.34 cm²/m², severe stenosis defined as <1.0 cm²)
   - Peak aortic jet velocity: 4.6 m/s (severe defined as >4.0 m/s)
   - Mean transvalvular gradient: 49 mmHg (severe defined as >40 mmHg)
   - Left Ventricular Ejection Fraction (LVEF): 48% with moderate concentric left ventricular hypertrophy
2. Coronary Angiography: Mild non-obstructive coronary artery disease (<30% stenosis in LAD and RCA).
3. Transcatheter Aortic Valve Replacement Multidetector CT (September 16, 2026): Iliofemoral access vessels demonstrate adequate luminal caliber (>6.0 mm bilaterally) with minimal tortuosity, confirming suitability for transfemoral approach.
4. Surgical Risk Assessment (STS Score): Calculated STS Prom score is 7.4% (Intermediate-to-High Surgical Risk for conventional open sternotomy).
5. Heart Team Consensus: Cardiothoracic Surgeon (Dr. H. Sterling) and Interventional Cardiologist (Dr. C. Wells) have co-evaluated the patient in accordance with CMS National Coverage Determination (NCD) 20.32. TAVR via transfemoral approach is unanimously recommended over surgical AVR given advanced age (82) and host comorbidities (porcelain aorta segments, chronic renal insufficiency Stage 3).

REQUESTED PROCEDURE:
CPT 33361 - Transcatheter aortic valve replacement (TAVR/TAVI) with prosthetic valve; percutaneous femoral artery approach.
Diagnosis: I35.0 - Nonrheumatic aortic valve stenosis; I50.9 - Heart failure, unspecified.`,
  },
  {
    id: 'case-neuro-04',
    title: 'Intractable Migraine with Red Flags - Brain MRI',
    category: 'Radiology / Advanced Neuroimaging',
    payer: 'Cigna',
    service: 'MRI Brain with and without IV Contrast',
    cpt: '70553',
    urgency: 'Standard (5-10 Days)',
    patientName: 'Samantha Chen',
    ehrNoteText: `NEUROLOGY OUTPATIENT CLINICAL SUMMARY
Patient: Samantha Chen | DOB: 03/29/1988 (Age 38) | Gender: F
MRN: 9140283 | Insurance: Cigna Open Access Plus | Member ID: CIG-99120485 | Group: 009218
Ordering Provider: Dr. Julian Ross, MD (NPI: 1780912433) - Comprehensive Headache & Stroke Center
Facility: Metro Imaging Partners Center (NPI: 1992014821)
Date of Encounter: September 23, 2026

CLINICAL HISTORY & RED FLAGS:
Ms. Chen is a 38-year-old female presenting with a 3-month history of subacutely worsening headache phenotype, now meeting strict American College of Radiology (ACR) Appropriateness Criteria for urgent neuroimaging.
Previous headache history was mild episodic tension headaches (<2 per month, responsive to ibuprofen). Over the past 90 days, she has developed intractable, daily holocephalic headaches waking her from sleep with projectile emesis.
Red Flag Focal Neurological Features:
- Persistent left upper extremity paresthesias and intermittent hemiparesis lasting >45 minutes during episodes.
- Fundoscopic examination reveals bilateral early optic disc margin blurring suggestive of grade 1 papilledema.
- New-onset cognitive slowing and word-finding hesitations reported by family.

DOCUMENTED PREVENTATIVE & ABORTIVE MEDICATION TRIALS:
1. Propranolol 80mg daily for 8 weeks: Discontinued due to symptomatic bradycardia (HR 44 bpm) and fatigue.
2. Topiramate titrated to 100mg daily for 6 weeks: Discontinued due to acute cognitive side effects and severe paresthesias.
3. Abortive therapy: Sumatriptan 100mg failed to provide relief; Rizatriptan 10mg failed; NSAIDs (Naproxen 500mg BID) completely ineffective.

REQUESTED SERVICE:
CPT 70553 - Magnetic resonance imaging, brain, including brain stem; without contrast material, followed by contrast material(s) and further sequences.
ICD-10 Diagnoses: G43.909 - Migraine, unspecified, not intractable, without status migrainosus; R42 - Dizziness and giddiness; H47.10 - Unspecified papilledema.
Medical Necessity: Rule out structural intracranial pathology, space-occupying lesion, dural arteriovenous fistula, or idiopathic intracranial hypertension. Contrast is mandatory to evaluate blood-brain barrier disruption and leptomeningeal enhancement.`,
  },
];

export const INITIAL_PRIOR_AUTH_RECORDS: PriorAuthRecord[] = [
  {
    id: 'PA-2026-8812',
    createdAt: '2026-09-22T09:14:00Z',
    updatedAt: '2026-09-22T11:45:00Z',
    status: 'review_needed',
    patient: {
      fullName: 'Robert Henderson',
      dob: '1962-05-14',
      gender: 'Male',
      memberId: 'UHC90448102-01',
      groupNumber: '712904',
      payerName: 'UnitedHealthcare',
      orderingProvider: {
        name: 'Dr. Arthur Sterling, MD, FAANS',
        npi: '1487692014',
        specialty: 'Neurological Surgery',
        facilityName: 'Boston Memorial Hospital Ambulatory Surgery Pavilion',
        contactPhone: '(617) 555-0182',
        faxNumber: '(617) 555-0199',
      },
    },
    clinical: {
      primaryDiagnosis: {
        code: 'M48.061',
        description: 'Spinal stenosis, lumbar region without neurogenic claudication',
      },
      secondaryDiagnoses: [
        { code: 'M54.16', description: 'Radiculopathy, lumbar region' },
        { code: 'M51.26', description: 'Other intervertebral disc displacement, lumbar region' },
      ],
      requestedService: {
        serviceName: 'Lumbar Hemilaminotomy & Microdiscectomy L4-L5',
        cptCode: '63030',
        units: 1,
        serviceSetting: 'Outpatient Surgical',
        urgency: 'Standard (5-10 Days)',
        anticipatedDate: '2026-10-14',
        estimatedCost: 14850,
      },
      conservativeTherapies: [
        {
          treatment: 'Physical Therapy (BayState Rehabilitation)',
          duration: '8 weeks (24 sessions)',
          outcome: 'Failed - persistent 8/10 radicular pain and ODI 58%',
          documentedDate: '2026-06-02 to 2026-07-28',
        },
        {
          treatment: 'Oral Pharmacotherapy (Meloxicam 15mg + Gabapentin 600mg TID)',
          duration: '8 weeks',
          outcome: 'Failed - minimal relief (<15%), Meloxicam stopped due to gastritis',
          documentedDate: '2026-07-01 to 2026-08-30',
        },
        {
          treatment: 'Fluoroscopic Right L4-L5 Transforaminal Epidural Steroid Injection',
          duration: '1 session',
          outcome: 'Failed - transient 4-day relief only with rapid rebound',
          documentedDate: '2026-08-11',
        },
      ],
      diagnosticFindings: [
        {
          testType: 'Lumbar Spine MRI (Without Contrast)',
          date: '2026-08-28',
          finding: 'L4-L5 severe disc extrusion 6.2mm with severe central stenosis (thecal sac 5.4mm) & right L5 root impingement',
          satisfiesCriteria: true,
        },
        {
          testType: 'Physical Examination',
          date: '2026-09-22',
          finding: 'Objective motor weakness: Right EHL 4/5, positive straight leg raise at 35 degrees',
          satisfiesCriteria: true,
        },
      ],
      contraindications: ['Further conservative therapy contraindicated due to progressive motor weakness'],
      functionalImpairmentSummary: 'Severe neurogenic claudication restricting walking to <50 yards. Unable to perform activities of daily living or work.',
    },
    guidelineReview: {
      guidelineName: 'InterQual 2026 / UHC Spine Surgery Medical Policy',
      allCriteriaMet: true,
      approvalConfidenceScore: 96,
      denialRiskPercentage: 4,
      denialRiskFactors: [],
      clinicalChecklist: [
        {
          criterionTitle: 'Documented failed conservative therapy >= 6 weeks within past 6 months',
          isMet: true,
          evidenceQuote: 'Completed 8 consecutive weeks of formal outpatient physical therapy at BayState Rehabilitation (24 sessions)',
        },
        {
          criterionTitle: 'Correlative imaging demonstrating nerve root compression or spinal stenosis',
          isMet: true,
          evidenceQuote: 'MRI demonstrates L4-L5 right paracentral disc extrusion measuring 6.2 mm, causing severe right L5 root impingement and AP diameter reduced to 5.4 mm',
        },
        {
          criterionTitle: 'Objective neurological deficit on physical examination',
          isMet: true,
          evidenceQuote: 'Right extensor hallucis longus (EHL) weakness 4/5; positive right SLR at 35 degrees',
        },
        {
          criterionTitle: 'Severe functional impairment (Oswestry > 40% or walking < 100m)',
          isMet: true,
          evidenceQuote: 'Oswestry Disability Index (ODI) score is 58%; walking tolerance severely restricted to <50 yards',
        },
      ],
    },
    payerFormFields: {
      box1_payerName: 'UnitedHealthcare Choice Plus',
      box2_patientName: 'Robert Henderson',
      box3_patientDob: '1962-05-14',
      box4_insuredId: 'UHC90448102-01',
      box5_groupNumber: '712904',
      box14_dateOfCurrentIllness: '2026-02-15',
      box21_diagnosisCodes: 'M48.061, M54.16, M51.26',
      box24_cptCodesWithModifiers: '63030-RT',
      box24_placeOfService: '24 - Ambulatory Surgical Center',
      box24_chargesEstimated: '$14,850.00',
      box25_federalTaxId: '04-2918402',
      box31_physicianSignatureDate: '2026-09-22',
      box32_serviceFacilityLocation: 'Boston Memorial Hospital Ambulatory Surgery Pavilion, 400 Medical Dr, Boston MA',
      box33_billingProviderInfo: 'Spine Institute of New England, NPI 1487692014, (617) 555-0182',
    },
    medicalNecessityLetter: `September 22, 2026\n\nAttn: Prior Authorization & Medical Review Department\nUnitedHealthcare\n\nRE: Prior Authorization Request for Lumbar Hemilaminotomy & Microdiscectomy (CPT 63030)\nPatient: Robert Henderson | DOB: 05/14/1962 | Member ID: UHC90448102-01 | Group: 712904\n\nDear Medical Director,\n\nI am writing to formally request prior authorization for an outpatient right L4-L5 hemilaminotomy and microdiscectomy (CPT 63030) for my patient, Mr. Robert Henderson. Mr. Henderson suffers from intractable right L5 radiculopathy secondary to a massive 6.2 mm right paracentral disc extrusion and severe central canal stenosis (AP diameter 5.4 mm), confirmed by lumbar MRI on August 28, 2026.\n\nIn accordance with UnitedHealthcare Clinical Policy for Lumbar Spine Surgery and InterQual Criteria, the patient has completed and failed >8 weeks of structured physical therapy (24 sessions), trials of NSAIDs and Gabapentin, and a targeted fluoroscopic transforaminal epidural steroid injection. He demonstrates objective progressive motor deficit (right EHL 4/5) and functional disability with ODI of 58%.\n\nContinued delay in decompression poses significant risk of permanent motor deficit. Thank you for your prompt authorization.\n\nSincerely,\nDr. Arthur Sterling, MD, FAANS\nSpine Institute of New England`,
    rawEhrText: SAMPLE_EHR_SCENARIOS[0].ehrNoteText,
    timeline: [
      {
        id: 't-1',
        timestamp: '2026-09-22T09:14:00Z',
        title: 'EHR Note Ingested',
        description: 'Encounter note imported from Boston Memorial Epic EHR',
        type: 'system',
        actor: 'AuthFlow EHR Connector',
      },
      {
        id: 't-2',
        timestamp: '2026-09-22T09:14:15Z',
        title: 'AI Clinical Extraction Completed',
        description: 'Extracted CPT 63030, ICD-10 M48.061, 8-week PT history, MRI stenosis measurements',
        type: 'ai',
        actor: 'AuthFlow Clinical AI',
      },
      {
        id: 't-3',
        timestamp: '2026-09-22T09:14:22Z',
        title: 'InterQual Guideline Audit Passed',
        description: 'All 4 clinical necessity criteria met (Confidence Score: 96%)',
        type: 'ai',
        actor: 'AuthFlow Rule Engine',
      },
      {
        id: 't-4',
        timestamp: '2026-09-22T09:15:00Z',
        title: 'Payer Form Auto-Filled',
        description: 'CMS-1500 & EDI 278 fields mapped and ready for clinician verification',
        type: 'system',
        actor: 'AuthFlow Form Engine',
      },
    ],
  },
  {
    id: 'PA-2026-8805',
    createdAt: '2026-09-20T14:30:00Z',
    updatedAt: '2026-09-21T10:15:00Z',
    status: 'approved',
    authorizationNumber: 'AUTH-UHC-992104-AP',
    validThrough: '2026-12-20',
    patient: {
      fullName: 'David Washington',
      dob: '1971-08-22',
      gender: 'Male',
      memberId: 'HUM-80921472',
      groupNumber: 'HUM-GRP-19',
      payerName: 'Humana Commercial',
      orderingProvider: {
        name: 'Dr. Rebecca Vance, MD',
        npi: '1789012345',
        specialty: 'Rheumatology',
        facilityName: 'Metro Health Outpatient Infusion Clinic',
        contactPhone: '(404) 555-0144',
        faxNumber: '(404) 555-0145',
      },
    },
    clinical: {
      primaryDiagnosis: {
        code: 'M05.79',
        description: 'Rheumatoid arthritis with rheumatoid factor of multiple sites without organ involvement',
      },
      secondaryDiagnoses: [],
      requestedService: {
        serviceName: 'Adalimumab (Humira) 40mg/0.4mL Subcutaneous Pen',
        cptCode: '96372',
        hcpcsCode: 'J0135',
        units: 2,
        serviceSetting: 'Ambulatory Clinic',
        urgency: 'Standard (5-10 Days)',
        anticipatedDate: '2026-10-01',
        estimatedCost: 6800,
      },
      conservativeTherapies: [
        {
          treatment: 'Oral Methotrexate 25mg weekly with folic acid',
          duration: '16 weeks',
          outcome: 'Failed - persistent DAS28 score 5.4 (high disease activity)',
          documentedDate: '2026-01-10 to 2026-05-15',
        },
        {
          treatment: 'Leflunomide 20mg daily combination',
          duration: '12 weeks',
          outcome: 'Failed - stopped due to transaminitis (>2x ULN)',
          documentedDate: '2026-05-20 to 2026-08-15',
        },
      ],
      diagnosticFindings: [
        {
          testType: 'Anti-CCP Antibodies & Rheumatoid Factor',
          date: '2026-08-20',
          finding: 'Anti-CCP >250 U/mL (strongly positive), RF 184 IU/mL',
          satisfiesCriteria: true,
        },
        {
          testType: 'QuantiFERON-TB Gold & Hep B Panel',
          date: '2026-08-25',
          finding: 'Negative for latent tuberculosis and chronic viral hepatitis',
          satisfiesCriteria: true,
        },
      ],
      contraindications: ['Failed two conventional synthetic DMARDs'],
      functionalImpairmentSummary: 'Severe morning stiffness >2 hours, inability to grasp tools at work.',
    },
    guidelineReview: {
      guidelineName: 'Humana Biologic DMARD Step Therapy Policy',
      allCriteriaMet: true,
      approvalConfidenceScore: 98,
      denialRiskPercentage: 2,
      denialRiskFactors: [],
      clinicalChecklist: [
        {
          criterionTitle: 'Confirmed diagnosis of moderate-to-severe Rheumatoid Arthritis',
          isMet: true,
          evidenceQuote: 'Anti-CCP >250 U/mL, DAS28 5.4, multiple synovitis joints',
        },
        {
          criterionTitle: 'Documented failure or intolerance to >= 1 conventional DMARD (Methotrexate)',
          isMet: true,
          evidenceQuote: 'Oral Methotrexate 25mg weekly for 16 weeks failed with high disease activity',
        },
        {
          criterionTitle: 'Negative TB and Hepatitis B screening prior to biologic initiation',
          isMet: true,
          evidenceQuote: 'QuantiFERON-TB Gold negative, Hepatitis B surface antigen negative',
        },
      ],
    },
    payerFormFields: {
      box1_payerName: 'Humana Commercial',
      box2_patientName: 'David Washington',
      box3_patientDob: '1971-08-22',
      box4_insuredId: 'HUM-80921472',
      box5_groupNumber: 'HUM-GRP-19',
      box14_dateOfCurrentIllness: '2025-11-01',
      box21_diagnosisCodes: 'M05.79',
      box24_cptCodesWithModifiers: '96372 / J0135',
      box24_placeOfService: '11 - Office',
      box24_chargesEstimated: '$6,800.00',
      box25_federalTaxId: '58-1928491',
      box31_physicianSignatureDate: '2026-09-20',
      box32_serviceFacilityLocation: 'Metro Health Outpatient Infusion Clinic',
      box33_billingProviderInfo: 'Metro Health Rheumatology Group',
    },
    medicalNecessityLetter: 'Formal Letter of Medical Necessity for Adalimumab completed and transmitted.',
    rawEhrText: 'Encounter note for David Washington - Refractory Rheumatoid Arthritis DMARD failure.',
    timeline: [
      {
        id: 't-201',
        timestamp: '2026-09-20T14:30:00Z',
        title: 'Intake and AI Extraction',
        description: 'Auto-extracted DMARD failure dates and negative TB test',
        type: 'ai',
        actor: 'AuthFlow AI',
      },
      {
        id: 't-202',
        timestamp: '2026-09-20T14:35:00Z',
        title: 'EDI 278 Transmitted',
        description: 'Electronic prior authorization sent to Humana clearinghouse',
        type: 'submission',
        actor: 'EDI Clearinghouse',
      },
      {
        id: 't-203',
        timestamp: '2026-09-21T10:15:00Z',
        title: 'Payer Approval Received (EDI 277)',
        description: 'Authorization AUTH-UHC-992104-AP approved for 6 months (Units: 12 pens)',
        type: 'payer_response',
        actor: 'Humana Portal',
      },
    ],
  },
  {
    id: 'PA-2026-8794',
    createdAt: '2026-09-19T11:00:00Z',
    updatedAt: '2026-09-21T16:20:00Z',
    status: 'denied',
    denialReason: 'Documentation lacks evidence of 6 consecutive weeks of conservative physical therapy logs within past 6 months under Aetna Clinical Policy Bulletin 0016.',
    denialCode: 'CARC 197 / RARC N382',
    patient: {
      fullName: 'Marcus Vance',
      dob: '1944-08-19',
      gender: 'Male',
      memberId: 'BCBS-88391024',
      groupNumber: 'ANT-401',
      payerName: 'Anthem Blue Cross',
      orderingProvider: {
        name: 'Dr. Cameron Wells, MD, FACC',
        npi: '1679041288',
        specialty: 'Interventional Cardiology',
        facilityName: 'St. Jude Heart & Vascular Hospital',
        contactPhone: '(312) 555-0199',
        faxNumber: '(312) 555-0198',
      },
    },
    clinical: {
      primaryDiagnosis: {
        code: 'I35.0',
        description: 'Nonrheumatic aortic valve stenosis',
      },
      secondaryDiagnoses: [{ code: 'I50.9', description: 'Heart failure, unspecified' }],
      requestedService: {
        serviceName: 'Transcatheter Aortic Valve Replacement (TAVR)',
        cptCode: '33361',
        units: 1,
        serviceSetting: 'Inpatient Hospital',
        urgency: 'Standard (5-10 Days)',
        anticipatedDate: '2026-10-05',
        estimatedCost: 52000,
      },
      conservativeTherapies: [],
      diagnosticFindings: [
        {
          testType: 'Echocardiogram',
          date: '2026-09-14',
          finding: 'Aortic Valve Area 0.62 cm², mean gradient 49 mmHg, peak velocity 4.6 m/s',
          satisfiesCriteria: true,
        },
      ],
      contraindications: ['High surgical open-heart risk (STS Prom 7.4%)'],
      functionalImpairmentSummary: 'NYHA Class III heart failure with syncopal episodes.',
    },
    guidelineReview: {
      guidelineName: 'Anthem Medical Policy - Transcatheter Valve Procedures',
      allCriteriaMet: false,
      approvalConfidenceScore: 68,
      denialRiskPercentage: 82,
      denialRiskFactors: ['Payer claims missing documentation on multidisciplinary heart team signed note'],
      clinicalChecklist: [
        {
          criterionTitle: 'Documented severe aortic stenosis (AVA < 1.0cm² or mean gradient > 40mmHg)',
          isMet: true,
          evidenceQuote: 'Aortic valve area 0.62 cm², mean gradient 49 mmHg',
        },
        {
          criterionTitle: 'Co-signed multidisciplinary heart team consensus (Cardiologist + Cardiac Surgeon)',
          isMet: false,
          evidenceQuote: 'Signed note from Dr. Wells present; formal independent note from Dr. Sterling claimed missing by payer',
          deficiencyRemediation: 'Attach Dr. Sterling co-signature and cardiac surgery clinic encounter note.',
        },
      ],
    },
    payerFormFields: {
      box1_payerName: 'Anthem Blue Cross',
      box2_patientName: 'Marcus Vance',
      box3_patientDob: '1944-08-19',
      box4_insuredId: 'BCBS-88391024',
      box5_groupNumber: 'ANT-401',
      box14_dateOfCurrentIllness: '2026-06-01',
      box21_diagnosisCodes: 'I35.0, I50.9',
      box24_cptCodesWithModifiers: '33361',
      box24_placeOfService: '21 - Inpatient Hospital',
      box24_chargesEstimated: '$52,000.00',
      box25_federalTaxId: '36-2918402',
      box31_physicianSignatureDate: '2026-09-19',
      box32_serviceFacilityLocation: 'St. Jude Heart & Vascular Hospital',
      box33_billingProviderInfo: 'Structural Heart Center of Chicago',
    },
    medicalNecessityLetter: 'Initial medical necessity letter submitted.',
    rawEhrText: SAMPLE_EHR_SCENARIOS[2].ehrNoteText,
    timeline: [
      {
        id: 't-301',
        timestamp: '2026-09-19T11:00:00Z',
        title: 'Prior Auth Request Submitted',
        description: 'Electronic submission via EDI 278 to Anthem Blue Cross',
        type: 'submission',
        actor: 'AuthFlow Gateway',
      },
      {
        id: 't-302',
        timestamp: '2026-09-21T16:20:00Z',
        title: 'Initial Denial Issued by Payer',
        description: 'Payer Medical Reviewer denied: missing independent CT Surgeon note (CARC 197)',
        type: 'payer_response',
        actor: 'Anthem Medical Director Dr. E. Hayes',
      },
    ],
  },
  {
    id: 'PA-2026-8820',
    createdAt: '2026-09-24T08:15:00Z',
    updatedAt: '2026-09-24T09:00:00Z',
    status: 'in_payer_review',
    patient: {
      fullName: 'Elena Rostova',
      dob: '1975-11-03',
      gender: 'Female',
      memberId: 'W984120938',
      groupNumber: '0882190',
      payerName: 'Aetna',
      orderingProvider: {
        name: 'Dr. Maya Lin, MD, PhD',
        npi: '1932084711',
        specialty: 'Medical Oncology',
        facilityName: 'Memorial Cancer Pavilion Infusion Suite',
        contactPhone: '(212) 555-0177',
        faxNumber: '(212) 555-0178',
      },
    },
    clinical: {
      primaryDiagnosis: {
        code: 'C50.911',
        description: 'Malignant neoplasm of unsp site of right female breast',
      },
      secondaryDiagnoses: [{ code: 'C79.51', description: 'Secondary malignant neoplasm of bone' }],
      requestedService: {
        serviceName: 'Trastuzumab (J9355) + Pertuzumab (J9306) Dual Biologic',
        cptCode: '96413',
        units: 1,
        serviceSetting: 'Infusion Suite',
        urgency: 'Urgent / Expedited (72 Hours)',
        anticipatedDate: '2026-09-28',
        estimatedCost: 28400,
      },
      conservativeTherapies: [],
      diagnosticFindings: [
        {
          testType: 'HER2 IHC & FISH Pathology',
          date: '2026-09-15',
          finding: 'IHC 3+ strongly positive, FISH amplification ratio 4.2',
          satisfiesCriteria: true,
        },
        {
          testType: 'Transthoracic Echocardiogram',
          date: '2026-09-18',
          finding: 'LVEF 62%, normal LV systolic function',
          satisfiesCriteria: true,
        },
      ],
      contraindications: ['None - patient is treatment-naive in metastatic setting'],
      functionalImpairmentSummary: 'Stage IV bone metastatic disease with bone pain.',
    },
    guidelineReview: {
      guidelineName: 'NCCN Category 1 / Aetna Specialty Pharmacy Precertification',
      allCriteriaMet: true,
      approvalConfidenceScore: 99,
      denialRiskPercentage: 1,
      denialRiskFactors: [],
      clinicalChecklist: [
        {
          criterionTitle: 'Histopathologically confirmed HER2 overexpression (IHC 3+ or FISH > 2.0)',
          isMet: true,
          evidenceQuote: 'HER2/neu positive (3+ by immunohistochemistry, confirmed by FISH ratio 4.2)',
        },
        {
          criterionTitle: 'Baseline cardiac evaluation with LVEF >= 50%',
          isMet: true,
          evidenceQuote: 'Transthoracic Echocardiogram LVEF 62%',
        },
        {
          criterionTitle: 'Metastatic or unresectable locally advanced disease',
          isMet: true,
          evidenceQuote: 'PET-CT demonstrates hypermetabolic osteolytic metastasis in L2 vertebral body',
        },
      ],
    },
    payerFormFields: {
      box1_payerName: 'Aetna Choice POS II',
      box2_patientName: 'Elena Rostova',
      box3_patientDob: '1975-11-03',
      box4_insuredId: 'W984120938',
      box5_groupNumber: '0882190',
      box14_dateOfCurrentIllness: '2026-09-01',
      box21_diagnosisCodes: 'C50.911, C79.51',
      box24_cptCodesWithModifiers: '96413 / J9355 / J9306',
      box24_placeOfService: '22 - On Campus Outpatient Hospital',
      box24_chargesEstimated: '$28,400.00',
      box25_federalTaxId: '13-3928192',
      box31_physicianSignatureDate: '2026-09-24',
      box32_serviceFacilityLocation: 'Memorial Cancer Pavilion Infusion Suite',
      box33_billingProviderInfo: 'Memorial Oncology Medical Group',
    },
    medicalNecessityLetter: 'Urgent Expedited Prior Authorization request for dual HER2 blockade.',
    rawEhrText: SAMPLE_EHR_SCENARIOS[1].ehrNoteText,
    timeline: [
      {
        id: 't-401',
        timestamp: '2026-09-24T08:15:00Z',
        title: 'Expedited Request Auto-Filled',
        description: '72-Hour urgent oncology tag applied based on metastatic status',
        type: 'ai',
        actor: 'AuthFlow Oncology Specialist AI',
      },
      {
        id: 't-402',
        timestamp: '2026-09-24T08:22:00Z',
        title: 'EDI 278 Transmitted to Availity/Aetna',
        description: 'Transaction ID #EDI278-AETNA-8819240',
        type: 'submission',
        actor: 'Availity Gateway',
      },
      {
        id: 't-403',
        timestamp: '2026-09-24T09:00:00Z',
        title: 'In Payer Review',
        description: 'Assigned to Medical Director for expedited clinical necessity review',
        type: 'payer_response',
        actor: 'Aetna Clinical Review Unit',
      },
    ],
  },
];
