import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { ClinicalIntakeView } from './components/ClinicalIntakeView';
import { PayerFormView } from './components/PayerFormView';
import { StatusTrackerView } from './components/StatusTrackerView';
import { RoiAnalyticsView } from './components/RoiAnalyticsView';
import { INITIAL_PRIOR_AUTH_RECORDS } from './data/mockClinicalCases';
import { PriorAuthRecord } from './types/priorAuth';

export default function App() {
  const [records, setRecords] = useState<PriorAuthRecord[]>(() => {
    try {
      const saved = localStorage.getItem('authflow_records');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return INITIAL_PRIOR_AUTH_RECORDS;
  });

  const [currentRecord, setCurrentRecord] = useState<PriorAuthRecord>(() => {
    return records[0] || INITIAL_PRIOR_AUTH_RECORDS[0];
  });

  const [activeTab, setActiveTab] = useState<'intake' | 'form' | 'tracker' | 'roi'>('tracker');

  // Persist records
  useEffect(() => {
    try {
      localStorage.setItem('authflow_records', JSON.stringify(records));
    } catch {
      // ignore
    }
  }, [records]);

  const handleUpdateRecord = (updated: PriorAuthRecord) => {
    setRecords((prev) => {
      const idx = prev.findIndex((r) => r.id === updated.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = updated;
        return copy;
      }
      return [updated, ...prev];
    });

    if (currentRecord.id === updated.id) {
      setCurrentRecord(updated);
    }
  };

  const handlePriorAuthReady = (newRecord: PriorAuthRecord) => {
    setRecords((prev) => [newRecord, ...prev.filter((r) => r.id !== newRecord.id)]);
    setCurrentRecord(newRecord);
  };

  const handleSelectForForm = (record: PriorAuthRecord) => {
    setCurrentRecord(record);
    setActiveTab('form');
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Hospital Platform Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        activePACount={records.filter((r) => r.status !== 'approved').length}
        onNewIntake={() => setActiveTab('intake')}
      />

      {/* Main View Outlet */}
      <main className="flex-1 pb-16">
        {activeTab === 'intake' && (
          <ClinicalIntakeView
            onPriorAuthReady={handlePriorAuthReady}
            onNavigateToForm={() => setActiveTab('form')}
          />
        )}

        {activeTab === 'form' && (
          <PayerFormView
            currentRecord={currentRecord}
            onUpdateRecord={handleUpdateRecord}
            onNavigateToTracker={() => setActiveTab('tracker')}
          />
        )}

        {activeTab === 'tracker' && (
          <StatusTrackerView
            records={records}
            onUpdateRecord={handleUpdateRecord}
            onSelectForForm={handleSelectForForm}
          />
        )}

        {activeTab === 'roi' && <RoiAnalyticsView />}
      </main>

      {/* Hospital Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">AuthFlow AI Platform</span>
            <span>·</span>
            <span>EHR Interoperability & EDI 278 Automated Prior Authorization</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>HIPAA Title II Protected</span>
            <span>·</span>
            <span>InterQual / MCG Integrated</span>
            <span>·</span>
            <span>CMS-0057-F Ready</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
