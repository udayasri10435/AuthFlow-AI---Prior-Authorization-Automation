export type PriorAuthStatus =
  | 'draft'
  | 'extracting'
  | 'review_needed'
  | 'submitted'
  | 'in_payer_review'
  | 'approved'
  | 'additional_info_required'
  | 'denied'
  | 'appealed'
  | 'peer_to_peer_scheduled';

export type ServiceUrgency = 'Standard (5-10 Days)' | 'Urgent / Expedited (72 Hours)';

export interface OrderingProvider {
  name: string;
  npi: string;
  specialty: string;
  facilityName: string;
  contactPhone: string;
  faxNumber: string;
}

export interface PatientInfo {
  fullName: string;
  dob: string;
  gender: string;
  memberId: string;
  groupNumber: string;
  payerName: string;
  orderingProvider: OrderingProvider;
}

export interface ClinicalDiagnosis {
  code: string;
  description: string;
}

export interface RequestedService {
  serviceName: string;
  cptCode: string;
  hcpcsCode?: string;
  ndcCode?: string;
  units: number;
  serviceSetting: 'Inpatient Hospital' | 'Outpatient Surgical' | 'Ambulatory Clinic' | 'Infusion Suite';
  urgency: ServiceUrgency;
  anticipatedDate: string;
  estimatedCost?: number;
}

export interface ConservativeTherapy {
  treatment: string;
  duration: string;
  outcome: string;
  documentedDate?: string;
}

export interface DiagnosticFinding {
  testType: string;
  date: string;
  finding: string;
  satisfiesCriteria: boolean;
}

export interface ClinicalChecklistCriterion {
  criterionTitle: string;
  isMet: boolean;
  evidenceQuote: string;
  deficiencyRemediation?: string;
}

export interface GuidelineReview {
  guidelineName: string; // e.g., "InterQual 2026 Spinal Procedures"
  allCriteriaMet: boolean;
  approvalConfidenceScore: number; // 0-100
  denialRiskPercentage: number; // 0-100
  denialRiskFactors: string[];
  clinicalChecklist: ClinicalChecklistCriterion[];
}

export interface PayerFormFields {
  box1_payerName: string;
  box2_patientName: string;
  box3_patientDob: string;
  box4_insuredId: string;
  box5_groupNumber: string;
  box14_dateOfCurrentIllness: string;
  box21_diagnosisCodes: string;
  box24_cptCodesWithModifiers: string;
  box24_placeOfService: string;
  box24_chargesEstimated: string;
  box25_federalTaxId: string;
  box31_physicianSignatureDate: string;
  box32_serviceFacilityLocation: string;
  box33_billingProviderInfo: string;
  [key: string]: string;
}

export interface TimelineEvent {
  id: string;
  timestamp: string;
  title: string;
  description: string;
  type: 'system' | 'ai' | 'submission' | 'payer_response' | 'appeal';
  actor: string;
}

export interface AppealDossier {
  appealLetter: string;
  clinicalCounterpoints: string[];
  literatureCitations: Array<{
    title: string;
    journal: string;
    clinicalTakeaway: string;
  }>;
  overturnProbabilityScore: number;
}

export interface PeerToPeerBrief {
  elevatorPitch: string;
  objectiveDataHighlights: string[];
  rebuttals: Array<{
    payerQuestion: string;
    recommendedAnswer: string;
  }>;
  closingDemandScript: string;
}

export interface PriorAuthRecord {
  id: string; // e.g. "PA-2026-8812"
  createdAt: string;
  updatedAt: string;
  status: PriorAuthStatus;
  patient: PatientInfo;
  clinical: {
    primaryDiagnosis: ClinicalDiagnosis;
    secondaryDiagnoses: ClinicalDiagnosis[];
    requestedService: RequestedService;
    conservativeTherapies: ConservativeTherapy[];
    diagnosticFindings: DiagnosticFinding[];
    contraindications: string[];
    functionalImpairmentSummary: string;
  };
  guidelineReview: GuidelineReview;
  payerFormFields: PayerFormFields;
  medicalNecessityLetter: string;
  authorizationNumber?: string;
  validThrough?: string;
  denialReason?: string;
  denialCode?: string;
  rawEhrText: string;
  timeline: TimelineEvent[];
  appealDossier?: AppealDossier;
  peerToPeerBrief?: PeerToPeerBrief;
  edi278TransactionId?: string;
}
