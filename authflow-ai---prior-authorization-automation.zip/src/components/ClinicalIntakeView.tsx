import React, { useState } from 'react';
import {
  Sparkles,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Building,
  UploadCloud,
  ArrowRight,
  ShieldAlert,
  Clock,
  Layers,
  FileCheck,
  Stethoscope,
} from 'lucide-react';
import { SAMPLE_EHR_SCENARIOS, SampleClinicalScenario } from '../data/mockClinicalCases';
import { extractClinicalPriorAuthData } from '../services/api';
import { PriorAuthRecord } from '../types/priorAuth';

interface ClinicalIntakeViewProps {
  onPriorAuthReady: (record: PriorAuthRecord) => void;
  onNavigateToForm: () => void;
}

export const ClinicalIntakeView: React.FC<ClinicalIntakeViewProps> = ({
  onPriorAuthReady,
  onNavigateToForm,
}) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(SAMPLE_EHR_SCENARIOS[0].id);
  const [clinicalText, setClinicalText] = useState<string>(SAMPLE_EHR_SCENARIOS[0].ehrNoteText);
  const [payer, setPayer] = useState<string>(SAMPLE_EHR_SCENARIOS[0].payer);
  const [urgency, setUrgency] = useState<'Standard (5-10 Days)' | 'Urgent / Expedited (72 Hours)'>('Standard (5-10 Days)');
  const [isExtracting, setIsExtracting] = useState<boolean>(false);
  const [extractionStage, setExtractionStage] = useState<string>('');
  const [extractionResult, setExtractionResult] = useState<PriorAuthRecord | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'clinical' | 'guidelines' | 'letter'>('clinical');

  const handleSelectScenario = (scenario: SampleClinicalScenario) => {
    setSelectedScenarioId(scenario.id);
    setClinicalText(scenario.ehrNoteText);
    setPayer(scenario.payer);
    setUrgency(scenario.urgency);
    setExtractionResult(null);
  };

  const handleRunAiExtraction = async () => {
    if (!clinicalText.trim()) return;

    setIsExtracting(true);
    setExtractionResult(null);

    // Multi-stage realistic progress
    setExtractionStage('Ingesting unstructured clinical EHR narrative & patient chart...');
    await new Promise((r) => setTimeout(r, 600));

    setExtractionStage('Abstracting primary ICD-10-CM codes and CPT/HCPCS procedure lines...');
    await new Promise((r) => setTimeout(r, 700));

    setExtractionStage('Auditing conservative therapy logs against InterQual & MCG clinical criteria...');
    await new Promise((r) => setTimeout(r, 700));

    setExtractionStage('Calculating payer denial probability & auto-mapping EDI 278 form fields...');

    try {
      const data = await extractClinicalPriorAuthData(clinicalText, payer, urgency);

      const newRecord: PriorAuthRecord = {
        id: `PA-2026-${Math.floor(1000 + Math.random() * 9000)}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        status: 'review_needed',
        patient: {
          fullName: data.patient?.fullName || 'Patient',
          dob: data.patient?.dob || '1965-01-01',
          gender: data.patient?.gender || 'Unknown',
          memberId: data.patient?.memberId || 'MEM-109284',
          groupNumber: data.patient?.groupNumber || 'GRP-001',
          payerName: payer,
          orderingProvider: data.patient?.orderingProvider || {
            name: 'Dr. Arthur Sterling, MD',
            npi: '1487692014',
            specialty: 'Specialist Physician',
            facilityName: 'Boston Memorial Hospital',
            contactPhone: '(617) 555-0182',
            faxNumber: '(617) 555-0199',
          },
        },
        clinical: {
          primaryDiagnosis: data.clinical?.primaryDiagnosis || {
            code: 'M48.061',
            description: 'Spinal stenosis, lumbar region',
          },
          secondaryDiagnoses: data.clinical?.secondaryDiagnoses || [],
          requestedService: {
            serviceName: data.clinical?.requestedService?.serviceName || 'Requested Procedure',
            cptCode: data.clinical?.requestedService?.cptCode || '63030',
            hcpcsCode: data.clinical?.requestedService?.hcpcsCode,
            ndcCode: data.clinical?.requestedService?.ndcCode,
            units: data.clinical?.requestedService?.units || 1,
            serviceSetting: (data.clinical?.requestedService?.serviceSetting as any) || 'Outpatient Surgical',
            urgency: urgency,
            anticipatedDate: data.clinical?.requestedService?.anticipatedDate || '2026-10-15',
            estimatedCost: 14800,
          },
          conservativeTherapies: data.clinical?.conservativeTherapies || [],
          diagnosticFindings: data.clinical?.diagnosticFindings || [],
          contraindications: data.clinical?.contraindications || [],
          functionalImpairmentSummary:
            data.clinical?.functionalImpairmentSummary || 'Severe functional and mobility impairment.',
        },
        guidelineReview: data.guidelineReview || {
          guidelineName: 'InterQual 2026 Clinical Coverage Policy',
          allCriteriaMet: true,
          approvalConfidenceScore: 94,
          denialRiskPercentage: 6,
          denialRiskFactors: [],
          clinicalChecklist: [
            {
              criterionTitle: 'Documented failed conservative therapy >= 6 weeks',
              isMet: true,
              evidenceQuote: 'Completed physical therapy and pharmacotherapy',
            },
          ],
        },
        payerFormFields: data.payerFormFields || {
          box1_payerName: payer,
          box2_patientName: data.patient?.fullName || 'Patient',
          box3_patientDob: data.patient?.dob || '1965-01-01',
          box4_insuredId: data.patient?.memberId || 'MEM-109284',
          box5_groupNumber: data.patient?.groupNumber || 'GRP-001',
          box14_dateOfCurrentIllness: '2026-03-01',
          box21_diagnosisCodes: data.clinical?.primaryDiagnosis?.code || 'M48.061',
          box24_cptCodesWithModifiers: data.clinical?.requestedService?.cptCode || '63030',
          box24_placeOfService: '24 - Ambulatory Surgical Center',
          box24_chargesEstimated: '$14,800.00',
          box25_federalTaxId: '04-2918402',
          box31_physicianSignatureDate: new Date().toISOString().split('T')[0],
          box32_serviceFacilityLocation: 'Boston Memorial Hospital Pavilion',
          box33_billingProviderInfo: 'Spine Institute of New England',
        },
        medicalNecessityLetter: data.medicalNecessityLetter || 'Letter of Medical Necessity generated.',
        rawEhrText: clinicalText,
        timeline: [
          {
            id: `tl-${Date.now()}-1`,
            timestamp: new Date().toISOString(),
            title: 'Clinical EHR Ingested',
            description: `Imported clinical documentation (${clinicalText.length} characters)`,
            type: 'system',
            actor: 'EHR Connector',
          },
          {
            id: `tl-${Date.now()}-2`,
            timestamp: new Date().toISOString(),
            title: 'AI Clinical Abstraction & Guideline Audit Complete',
            description: `Extracted CPT ${data.clinical?.requestedService?.cptCode} and ICD-10 ${data.clinical?.primaryDiagnosis?.code}. Confidence score: ${data.guidelineReview?.approvalConfidenceScore || 95}%.`,
            type: 'ai',
            actor: 'AuthFlow AI Engine',
          },
        ],
      };

      setExtractionResult(newRecord);
      onPriorAuthReady(newRecord);
    } catch (err) {
      console.error('Extraction failed:', err);
    } finally {
      setIsExtracting(false);
      setExtractionStage('');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner & Context */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 rounded-2xl p-6 sm:p-8 text-white shadow-xl border border-slate-700/60 relative overflow-hidden">
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 text-cyan-400 text-xs font-semibold uppercase tracking-wider bg-cyan-950/60 px-2.5 py-1 rounded-md border border-cyan-800/40">
            <Sparkles className="w-3.5 h-3.5" />
            Clinical Intelligence Engine
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            AI Clinical Data Extraction & Guideline Verification
          </h1>
          <p className="text-slate-300 text-sm leading-relaxed">
            Eliminate hours of manual chart-hunting. Ingest unstructured physician notes, operative records, and imaging reports to automatically extract ICD-10/CPT codes, audit conservative care criteria against InterQual/MCG, and generate a pre-validated prior authorization packet.
          </p>
        </div>
      </div>

      {/* Preset Scenario Selector */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-semibold text-slate-900">Select Clinical Scenario or Paste EHR Note</h2>
            <p className="text-xs text-slate-500">Choose an authentic high-complexity hospital case to evaluate AI extraction</p>
          </div>
          <span className="text-xs text-slate-500 hidden sm:inline">
            4 Pre-loaded clinical scenarios
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {SAMPLE_EHR_SCENARIOS.map((scenario) => {
            const isSelected = selectedScenarioId === scenario.id;
            return (
              <button
                key={scenario.id}
                onClick={() => handleSelectScenario(scenario)}
                className={`text-left p-4 rounded-xl border transition-all relative ${
                  isSelected
                    ? 'border-blue-600 bg-blue-50/50 shadow-sm ring-1 ring-blue-600'
                    : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/80'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="text-[11px] font-semibold tracking-wide uppercase text-blue-700">
                    {scenario.category}
                  </span>
                  {isSelected && (
                    <CheckCircle2 className="w-4 h-4 text-blue-600 flex-shrink-0" />
                  )}
                </div>
                <h3 className="font-semibold text-sm text-slate-900 mt-1 line-clamp-1">
                  {scenario.title}
                </h3>
                <div className="mt-2 text-xs text-slate-500 space-y-1">
                  <div className="flex items-center justify-between">
                    <span>Patient:</span>
                    <strong className="text-slate-700 font-medium">{scenario.patientName}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Target Payer:</span>
                    <strong className="text-slate-700 font-medium">{scenario.payer}</strong>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>CPT Code:</span>
                    <span className="font-mono text-slate-800 font-semibold">{scenario.cpt}</span>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Intake Form: Textarea & Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: EHR Clinical Note Input */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="bg-slate-50 border-b border-slate-200 px-4 py-3 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
                <FileText className="w-4 h-4 text-blue-600" />
                <span>EHR Clinical Documentation (Physician Encounter & Diagnostic Reports)</span>
              </div>
              <span className="text-[11px] text-slate-400">
                {clinicalText.length} characters
              </span>
            </div>
            <div className="p-4">
              <textarea
                value={clinicalText}
                onChange={(e) => {
                  setClinicalText(e.target.value);
                  setSelectedScenarioId('custom');
                }}
                rows={14}
                className="w-full text-xs font-mono text-slate-800 bg-slate-50/50 border border-slate-200 rounded-lg p-3.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent leading-relaxed resize-y"
                placeholder="Paste unformatted clinical encounter note, operative summary, or lab/imaging impression..."
              />
            </div>
          </div>
        </div>

        {/* Right Col: Payer & Trigger Settings */}
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-4">
            <h3 className="text-sm font-semibold text-slate-900 flex items-center gap-2">
              <Building className="w-4 h-4 text-slate-600" />
              Prior Auth Parameters
            </h3>

            {/* Payer Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-700">Target Insurance Payer</label>
              <select
                value={payer}
                onChange={(e) => setPayer(e.target.value)}
                className="w-full text-xs text-slate-800 bg-white border border-slate-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="UnitedHealthcare">UnitedHealthcare (UHC Commercial & Optum)</option>
                <option value="Aetna">Aetna (POS II / Commercial / Eviti)</option>
                <option value="Cigna">Cigna (Open Access Plus & Evernorth)</option>
                <option value="Anthem Blue Cross">Anthem Blue Cross Blue Shield</option>
                <option value="Humana">Humana (Commercial & Medicare Advantage)</option>
                <option value="Medicare Advantage">CMS Traditional Medicare / Medicare Advantage</option>
                <option value="Molina Healthcare">Molina Healthcare</option>
              </select>
              <p className="text-[11px] text-slate-400">
                Guides InterQual/MCG medical policies and clearinghouse EDI routing
              </p>
            </div>

            {/* Urgency Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-700">Turnaround Requirement</label>
              <select
                value={urgency}
                onChange={(e) => setUrgency(e.target.value as any)}
                className="w-full text-xs text-slate-800 bg-white border border-slate-300 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="Standard (5-10 Days)">Standard Elective (5-10 Business Days)</option>
                <option value="Urgent / Expedited (72 Hours)">Urgent / Expedited (72 Hours - Clinical Risk)</option>
              </select>
            </div>

            {/* Quality Checks */}
            <div className="bg-slate-50 rounded-lg p-3 border border-slate-200 space-y-2 text-xs text-slate-600">
              <div className="font-medium text-slate-800 flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-blue-600" />
                Pre-Extraction Pipeline:
              </div>
              <ul className="space-y-1 text-[11px] text-slate-500">
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                  ICD-10-CM specificity crosswalk
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                  Conservative care threshold checks (&ge; 6 weeks)
                </li>
                <li className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                  Automated EDI 278 loop mapping
                </li>
              </ul>
            </div>

            {/* Extraction Action Button */}
            <button
              onClick={handleRunAiExtraction}
              disabled={isExtracting || !clinicalText.trim()}
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 text-white font-medium text-xs px-4 py-3 rounded-lg shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {isExtracting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                  <span>Extracting Clinical Entities...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-cyan-300" />
                  <span>Run AI Extraction & Guideline Audit</span>
                </>
              )}
            </button>

            {isExtracting && (
              <div className="bg-blue-50 rounded-lg p-3 border border-blue-200 text-xs text-blue-800 space-y-1.5 animate-pulse">
                <div className="font-semibold text-blue-900 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  Processing Clinical Chart:
                </div>
                <p className="text-[11px] text-blue-700">{extractionStage}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Extraction Results Section (Shows as soon as extracted) */}
      {extractionResult && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-lg overflow-hidden space-y-6 p-6 transition-all">
          {/* Header of results */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-5 border-b border-slate-200 gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold uppercase text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  Clinical Extraction Verified
                </span>
                <span className="text-xs text-slate-500">·</span>
                <span className="text-xs font-mono text-slate-600">ID: {extractionResult.id}</span>
              </div>
              <h2 className="text-lg font-bold text-slate-900 mt-1">
                {extractionResult.patient.fullName} · {extractionResult.clinical.requestedService.serviceName}
              </h2>
              <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
                <span>DOB: {extractionResult.patient.dob}</span>
                <span aria-hidden="true">·</span>
                <span>Member ID: {extractionResult.patient.memberId}</span>
                <span aria-hidden="true">·</span>
                <span>Payer: {extractionResult.patient.payerName}</span>
              </div>
            </div>

            {/* Quick action button to proceed to payer form */}
            <button
              onClick={onNavigateToForm}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-sm transition-all focus:outline-none"
            >
              <span>Auto-Fill Payer Form (EDI 278)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Sub-tabs inside results */}
          <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
            <button
              onClick={() => setActiveSubTab('clinical')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeSubTab === 'clinical'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Extracted Clinical Entities
            </button>
            <button
              onClick={() => setActiveSubTab('guidelines')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 ${
                activeSubTab === 'guidelines'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <span>InterQual / MCG Criteria Checklist</span>
              <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-1.5 py-0.2 rounded">
                {extractionResult.guidelineReview.approvalConfidenceScore}%
              </span>
            </button>
            <button
              onClick={() => setActiveSubTab('letter')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeSubTab === 'letter'
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              Letter of Medical Necessity
            </button>
          </div>

          {/* Tab 1: Clinical Entities */}
          {activeSubTab === 'clinical' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Left Column: Diagnoses & Requested Procedures */}
              <div className="space-y-4">
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <Stethoscope className="w-3.5 h-3.5 text-blue-600" />
                    ICD-10 Diagnoses & Coding
                  </h4>
                  <div className="space-y-2">
                    <div className="bg-white p-3 rounded-lg border border-slate-200">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-500 font-medium">Primary ICD-10:</span>
                        <span className="font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                          {extractionResult.clinical.primaryDiagnosis.code}
                        </span>
                      </div>
                      <p className="text-xs text-slate-800 font-medium mt-1">
                        {extractionResult.clinical.primaryDiagnosis.description}
                      </p>
                    </div>

                    {extractionResult.clinical.secondaryDiagnoses.map((sec, i) => (
                      <div key={i} className="bg-white p-2.5 rounded-lg border border-slate-200">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-slate-500 font-medium">Secondary ICD-10:</span>
                          <span className="font-mono text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded">
                            {sec.code}
                          </span>
                        </div>
                        <p className="text-xs text-slate-700 mt-0.5">{sec.description}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <FileCheck className="w-3.5 h-3.5 text-blue-600" />
                    Requested Procedure / Service
                  </h4>
                  <div className="bg-white p-3 rounded-lg border border-slate-200 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Procedure Name:</span>
                      <strong className="text-slate-800">{extractionResult.clinical.requestedService.serviceName}</strong>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">CPT / HCPCS:</span>
                      <span className="font-mono font-bold text-blue-700 bg-blue-50 px-2 py-0.5 rounded">
                        {extractionResult.clinical.requestedService.cptCode}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Place of Service:</span>
                      <span className="text-slate-700">{extractionResult.clinical.requestedService.serviceSetting}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Urgency:</span>
                      <span className="text-slate-800 font-medium">{extractionResult.clinical.requestedService.urgency}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right Column: Conservative Therapies & Diagnostic Evidence */}
              <div className="space-y-4">
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-blue-600" />
                    Prior Conservative Care History (Crucial for Approval)
                  </h4>
                  {extractionResult.clinical.conservativeTherapies.length === 0 ? (
                    <p className="text-xs text-slate-500 italic">No prior conservative therapies documented or required for this acute indication.</p>
                  ) : (
                    <div className="space-y-2">
                      {extractionResult.clinical.conservativeTherapies.map((ct, idx) => (
                        <div key={idx} className="bg-white p-3 rounded-lg border border-slate-200 text-xs space-y-1">
                          <div className="flex items-center justify-between">
                            <strong className="text-slate-800">{ct.treatment}</strong>
                            <span className="text-[11px] text-blue-700 font-medium bg-blue-50 px-1.5 py-0.5 rounded">
                              {ct.duration}
                            </span>
                          </div>
                          <p className="text-slate-600 text-[11px]">Outcome: {ct.outcome}</p>
                          {ct.documentedDate && (
                            <p className="text-slate-400 text-[10px]">Dates: {ct.documentedDate}</p>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-3">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    Objective Diagnostic & Imaging Findings
                  </h4>
                  <div className="space-y-2">
                    {extractionResult.clinical.diagnosticFindings.map((df, idx) => (
                      <div key={idx} className="bg-white p-3 rounded-lg border border-slate-200 text-xs space-y-1">
                        <div className="flex items-center justify-between">
                          <strong className="text-slate-800">{df.testType}</strong>
                          <span className="text-[10px] text-slate-400">{df.date}</span>
                        </div>
                        <p className="text-slate-700 text-[11px] leading-relaxed">{df.finding}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: InterQual / MCG Criteria Checklist */}
          {activeSubTab === 'guidelines' && (
            <div className="space-y-6">
              {/* Score bar */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-emerald-50 rounded-xl p-4 border border-emerald-200">
                  <div className="text-xs text-emerald-700 font-medium">InterQual Medical Policy</div>
                  <div className="text-xl font-bold text-emerald-900 mt-1">
                    {extractionResult.guidelineReview.guidelineName}
                  </div>
                  <div className="text-xs text-emerald-700 mt-1">
                    Status: {extractionResult.guidelineReview.allCriteriaMet ? 'All Required Criteria Satisfied' : 'Review Criteria'}
                  </div>
                </div>

                <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
                  <div className="text-xs text-blue-700 font-medium">First-Pass Approval Probability</div>
                  <div className="text-2xl font-bold text-blue-900 mt-1">
                    {extractionResult.guidelineReview.approvalConfidenceScore}%
                  </div>
                  <div className="text-xs text-blue-600 mt-1">
                    Validated against {extractionResult.patient.payerName} Medical Bulletin
                  </div>
                </div>

                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200">
                  <div className="text-xs text-slate-600 font-medium">Denial Risk Assessment</div>
                  <div className="text-2xl font-bold text-slate-900 mt-1">
                    {extractionResult.guidelineReview.denialRiskPercentage}%
                  </div>
                  <div className="text-xs text-emerald-600 font-medium mt-1">
                    Low risk profile for technical denial
                  </div>
                </div>
              </div>

              {/* Criterion Breakdown */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Criterion-by-Criterion Audit
                </h4>
                <div className="space-y-2.5">
                  {extractionResult.guidelineReview.clinicalChecklist.map((item, idx) => (
                    <div
                      key={idx}
                      className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs flex items-start gap-3"
                    >
                      <div className="mt-0.5">
                        {item.isMet ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                        ) : (
                          <AlertTriangle className="w-5 h-5 text-amber-500" />
                        )}
                      </div>
                      <div className="space-y-1 flex-1">
                        <div className="flex items-center justify-between">
                          <h5 className="text-xs font-semibold text-slate-900">{item.criterionTitle}</h5>
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                              item.isMet ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700'
                            }`}
                          >
                            {item.isMet ? 'MET' : 'GAP DETECTED'}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 bg-slate-50 p-2 rounded border border-slate-200/80 italic font-mono">
                          "{item.evidenceQuote}"
                        </p>
                        {item.deficiencyRemediation && (
                          <p className="text-[11px] text-amber-700 font-medium">
                            Remediation: {item.deficiencyRemediation}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Tab 3: Medical Necessity Letter */}
          {activeSubTab === 'letter' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-semibold text-slate-900">Generated Letter of Medical Necessity</h4>
                  <p className="text-xs text-slate-500">Ready for attending physician digital signature & clearinghouse transmission</p>
                </div>
                <button
                  onClick={() => navigator.clipboard.writeText(extractionResult.medicalNecessityLetter)}
                  className="text-xs font-semibold text-blue-600 hover:text-blue-800 px-3 py-1.5 rounded border border-blue-200 hover:bg-blue-50 transition-colors"
                >
                  Copy Letter Text
                </button>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 font-mono text-xs text-slate-800 leading-relaxed whitespace-pre-wrap">
                {extractionResult.medicalNecessityLetter}
              </div>
            </div>
          )}

          {/* Bottom Bar: Action buttons */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              onClick={onNavigateToForm}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold px-5 py-2.5 rounded-lg shadow-sm transition-all focus:outline-none"
            >
              <span>Auto-Fill Payer Form (EDI 278)</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
