import React, { useState } from 'react';
import {
  X,
  Scale,
  Sparkles,
  BookOpen,
  CheckCircle2,
  Send,
  Printer,
  Copy,
  AlertTriangle,
} from 'lucide-react';
import { PriorAuthRecord, AppealDossier } from '../types/priorAuth';
import { generateAiAppealDossier } from '../services/api';

interface AppealModalProps {
  record: PriorAuthRecord;
  onClose: () => void;
  onAppealSubmitted: (updatedRecord: PriorAuthRecord) => void;
}

export const AppealModal: React.FC<AppealModalProps> = ({
  record,
  onClose,
  onAppealSubmitted,
}) => {
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [dossier, setDossier] = useState<AppealDossier | null>(record.appealDossier || null);
  const [denialReason, setDenialReason] = useState<string>(
    record.denialReason || 'Payer claims insufficient documentation of conservative physical therapy duration.'
  );
  const [additionalEvidence, setAdditionalEvidence] = useState<string>(
    'Attending surgeon notes patient exhibits progressive motor deficit (EHL 4/5 weakness) and intractable neurogenic claudication. Delaying surgical intervention creates substantial risk of permanent neurological deficit.'
  );
  const [copied, setCopied] = useState<boolean>(false);

  const handleGenerateAppeal = async () => {
    setIsGenerating(true);
    try {
      const generated = await generateAiAppealDossier(
        record,
        denialReason,
        record.denialCode || 'CARC 197 / RARC N382',
        additionalEvidence
      );
      setDossier(generated);
    } catch (err) {
      console.error('Failed to generate appeal:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmitAppeal = () => {
    if (!dossier) return;

    const updatedRecord: PriorAuthRecord = {
      ...record,
      status: 'appealed',
      appealDossier: dossier,
      updatedAt: new Date().toISOString(),
      timeline: [
        ...record.timeline,
        {
          id: `tl-app-${Date.now()}`,
          timestamp: new Date().toISOString(),
          title: 'Level 1 Expedited Reconsideration & Appeal Submitted',
          description: `Formal Appeal Dossier transmitted to ${record.patient.payerName} Appeals Committee with peer-reviewed clinical citations.`,
          type: 'appeal',
          actor: 'AuthFlow Appeal Engine',
        },
      ],
    };

    onAppealSubmitted(updatedRecord);
    onClose();
  };

  const handleCopy = () => {
    if (!dossier) return;
    navigator.clipboard.writeText(dossier.appealLetter);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-500/20 text-red-400 border border-red-500/40 flex items-center justify-center">
              <Scale className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>AI Prior Authorization Appeal & Reconsideration Dossier</span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-red-950 text-red-300 border border-red-800">
                  Level 1 Expedited
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Patient: {record.patient.fullName} · Payer: {record.patient.payerName} · Service: {record.clinical.requestedService.serviceName}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-800">
          {/* Denial Context Card */}
          <div className="bg-red-50 border border-red-200 rounded-xl p-4 text-xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-red-900 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-red-600" />
                Payer Denial Determination:
              </span>
              <span className="font-mono font-semibold text-red-700 bg-red-100 px-2 py-0.5 rounded">
                {record.denialCode || 'CARC 197 / RARC N382'}
              </span>
            </div>
            <p className="text-red-800 leading-relaxed font-medium">"{denialReason}"</p>
          </div>

          {/* Form to tweak or generate if not generated */}
          {!dossier && (
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-700">
                  Additional Clinical Evidence / Counter-Arguments for Appeal
                </label>
                <textarea
                  rows={3}
                  value={additionalEvidence}
                  onChange={(e) => setAdditionalEvidence(e.target.value)}
                  className="w-full text-xs text-slate-800 bg-slate-50 border border-slate-300 rounded-lg p-3 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <button
                onClick={handleGenerateAppeal}
                disabled={isGenerating}
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 text-white font-semibold text-xs px-4 py-3 rounded-lg shadow-sm transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {isGenerating ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                    <span>Synthesizing Clinical Evidence, Legal Precedents & NEJM Literature...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-cyan-300" />
                    <span>Generate Appeal Dossier with Gemini 3.8 Flash</span>
                  </>
                )}
              </button>
            </div>
          )}

          {/* Generated Dossier Display */}
          {dossier && (
            <div className="space-y-6">
              {/* Overturn Probability & Strategy summary */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-emerald-50 rounded-xl p-4 border border-emerald-200">
                  <div className="text-xs text-emerald-700 font-medium">Overturn Probability Score</div>
                  <div className="text-2xl font-bold text-emerald-900 mt-1">
                    {dossier.overturnProbabilityScore}%
                  </div>
                  <div className="text-[11px] text-emerald-700 mt-0.5">
                    High probability under ERISA § 503
                  </div>
                </div>

                <div className="bg-blue-50 rounded-xl p-4 border border-blue-200 sm:col-span-2">
                  <div className="text-xs text-blue-700 font-medium">Key Clinical Counterarguments</div>
                  <ul className="text-xs text-blue-900 mt-1 space-y-1 list-disc list-inside">
                    {dossier.clinicalCounterpoints.map((cp, idx) => (
                      <li key={idx} className="leading-snug">
                        {cp}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Peer-reviewed literature citations */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-blue-600" />
                  Peer-Reviewed Clinical Evidence & Landmark Trials Cited
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {dossier.literatureCitations.map((lit, idx) => (
                    <div key={idx} className="bg-slate-50 p-3 rounded-lg border border-slate-200 text-xs space-y-1">
                      <div className="font-bold text-slate-900 leading-snug">{lit.title}</div>
                      <div className="text-[11px] text-blue-700 font-medium">{lit.journal}</div>
                      <p className="text-[11px] text-slate-600 mt-1 leading-relaxed">
                        Takeaway: {lit.clinicalTakeaway}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Full Formal Appeal Letter */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Formal Reconsideration Letter
                  </h4>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleCopy}
                      className="text-xs font-medium text-slate-600 hover:text-slate-900 flex items-center gap-1 bg-slate-100 hover:bg-slate-200 px-2.5 py-1 rounded transition-colors"
                    >
                      <Copy className="w-3 h-3" />
                      <span>{copied ? 'Copied!' : 'Copy'}</span>
                    </button>
                    <button
                      onClick={() => window.print()}
                      className="text-xs font-medium text-slate-600 hover:text-slate-900 flex items-center gap-1 bg-slate-100 hover:bg-slate-200 px-2.5 py-1 rounded transition-colors"
                    >
                      <Printer className="w-3 h-3" />
                      <span>Print</span>
                    </button>
                  </div>
                </div>

                <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 font-mono text-xs text-slate-800 leading-relaxed whitespace-pre-wrap max-h-64 overflow-y-auto">
                  {dossier.appealLetter}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="text-xs text-slate-600 hover:text-slate-900 px-3 py-2 rounded-lg"
          >
            Cancel
          </button>

          {dossier && (
            <button
              onClick={handleSubmitAppeal}
              className="flex items-center gap-2 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-xs font-semibold px-5 py-2.5 rounded-lg shadow-sm transition-all cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>Submit Formal Appeal to Payer</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
