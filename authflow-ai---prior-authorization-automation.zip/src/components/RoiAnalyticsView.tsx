import React, { useState } from 'react';
import {
  TrendingUp,
  Clock,
  DollarSign,
  ShieldCheck,
  Users,
  AlertOctagon,
  Sparkles,
  ArrowUpRight,
  CheckCircle2,
  FileCheck,
  Building2,
  HelpCircle,
} from 'lucide-react';

export const RoiAnalyticsView: React.FC = () => {
  // Interactive Hospital Calculator State
  const [bedCount, setBedCount] = useState<number>(300);
  const [monthlyVolume, setMonthlyVolume] = useState<number>(950);
  const [hourlyWage, setHourlyWage] = useState<number>(45);
  const [currentDenialRate, setCurrentDenialRate] = useState<number>(18);
  const [avgProcedureRevenue, setAvgProcedureRevenue] = useState<number>(11500);

  // Calculations
  const manualTimeHours = 4.2; // 4.2 hours per manual PA (chart hunting, portal re-entry, peer-to-peer prep)
  const automatedTimeHours = 0.11; // ~6.5 minutes per PA with AI
  const hoursSavedPerPA = manualTimeHours - automatedTimeHours;

  const annualPAVolume = monthlyVolume * 12;
  const annualHoursSaved = Math.round(annualPAVolume * hoursSavedPerPA);

  // Cost per PA comparison
  const manualCostPerPA = Math.round(manualTimeHours * hourlyWage * 100) / 100;
  const automatedCostPerPA = Math.round(automatedTimeHours * hourlyWage * 100) / 100;

  // Financial Labor Savings
  const annualLaborSavings = Math.round(annualHoursSaved * hourlyWage);

  // Denial Reduction Savings:
  // Baseline denials: e.g. 18% -> With AI gap verification: ~4.5% (75% relative reduction in avoidable technical denials)
  const baselineDenialsPerYear = Math.round((annualPAVolume * currentDenialRate) / 100);
  const preventedDenialsPerYear = Math.round(baselineDenialsPerYear * 0.72);
  // Assume ~15% of initial denials result in permanent lost revenue or costly appeals write-off
  const revenuePreserved = Math.round(preventedDenialsPerYear * 0.18 * avgProcedureRevenue);

  // Total Annual Financial Impact
  const totalAnnualValue = annualLaborSavings + revenuePreserved;

  // Estimated platform subscription cost based on volume
  const estimatedPlatformCost = Math.round(annualPAVolume * 6.5);
  const netRoiDollar = totalAnnualValue - estimatedPlatformCost;
  const roiMultiple = Math.round((netRoiDollar / (estimatedPlatformCost || 1)) * 10) / 10;
  const paybackDays = Math.max(8, Math.round((estimatedPlatformCost / (totalAnnualValue / 365))));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl border border-slate-700/60 relative overflow-hidden">
        <div className="relative z-10 max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 text-emerald-400 text-xs font-semibold uppercase tracking-wider bg-emerald-950/60 px-2.5 py-1 rounded-md border border-emerald-800/40">
            <TrendingUp className="w-3.5 h-3.5" />
            Hospital Economics & Executive Business Case
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Prior Authorization Automation ROI & Denial Economics
          </h1>
          <p className="text-slate-300 text-sm leading-relaxed">
            Prior authorization is the #1 administrative burden cited by American Hospital Association (AHA) and AMA. Discover how eliminating chart hunting, auto-completing payer forms, and verifying InterQual guidelines generates millions in direct labor reclamation and preserved surgical revenue.
          </p>
        </div>
      </div>

      {/* Top 4 Impact Pillars */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Pillar 1: Turnaround Time */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Turnaround Time (TAT)</span>
            <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">
              84% Faster
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">1.1</span>
            <span className="text-xs text-slate-500">Days (vs 7.8 Days Manual)</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Slashes surgical scheduling delays, eliminates patient cancellations, and prevents unbilled bed days.
          </p>
        </div>

        {/* Pillar 2: Cost Per PA */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Cost per Authorization</span>
            <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">
              91% Reduction
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">${automatedCostPerPA.toFixed(2)}</span>
            <span className="text-xs text-slate-500">vs ${manualCostPerPA.toFixed(2)} Manual</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Eliminates 4.2 hours of manual chart abstraction, faxing, and portal re-entry per clinical case.
          </p>
        </div>

        {/* Pillar 3: First-Pass Clean Approval */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>First-Pass Approval Rate</span>
            <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">
              +26.8% Gain
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">94.8%</span>
            <span className="text-xs text-slate-500">vs 68.0% Industry Avg</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            InterQual & MCG pre-submission checklist prevents technical denials before EDI transmission.
          </p>
        </div>

        {/* Pillar 4: A/R Days Accelerated */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-500 font-medium">
            <span>Days in A/R Accelerated</span>
            <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded">
              14 Days Faster
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">-14</span>
            <span className="text-xs text-slate-500">Days to Cash Collection</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed">
            Pre-cleared authorizations guarantee uninterrupted claims adjudication with zero authorization retro-denials.
          </p>
        </div>
      </div>

      {/* Main Interactive Hospital ROI Calculator */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-6 sm:p-8 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-2">
          <div>
            <div className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-blue-600" />
              <h2 className="text-lg font-bold text-slate-900">
                Interactive Hospital ROI Financial Simulator
              </h2>
            </div>
            <p className="text-xs text-slate-500">
              Customize parameters to your health system bed size, PA volume, and clinical staff costs
            </p>
          </div>
          <div className="text-xs text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
            Model: AHA & CAQH Index Cost Benchmarks
          </div>
        </div>

        {/* Sliders Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Slider 1: Bed Count */}
          <div className="space-y-2 bg-slate-50/70 p-4 rounded-xl border border-slate-200">
            <div className="flex items-center justify-between text-xs">
              <label className="font-semibold text-slate-700">Hospital Licensed Beds</label>
              <span className="font-bold text-slate-900">{bedCount} beds</span>
            </div>
            <input
              type="range"
              min={50}
              max={1200}
              step={25}
              value={bedCount}
              onChange={(e) => {
                const val = Number(e.target.value);
                setBedCount(val);
                setMonthlyVolume(Math.round(val * 3.2));
              }}
              className="w-full accent-blue-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>Community (50)</span>
              <span>Regional (600)</span>
              <span>Academic (1200+)</span>
            </div>
          </div>

          {/* Slider 2: Monthly PA Volume */}
          <div className="space-y-2 bg-slate-50/70 p-4 rounded-xl border border-slate-200">
            <div className="flex items-center justify-between text-xs">
              <label className="font-semibold text-slate-700">Monthly Prior Auth Volume</label>
              <span className="font-bold text-slate-900">{monthlyVolume} PAs / mo</span>
            </div>
            <input
              type="range"
              min={100}
              max={4000}
              step={50}
              value={monthlyVolume}
              onChange={(e) => setMonthlyVolume(Number(e.target.value))}
              className="w-full accent-blue-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>100 / mo</span>
              <span>2,000 / mo</span>
              <span>4,000 / mo</span>
            </div>
          </div>

          {/* Slider 3: Hourly Wage */}
          <div className="space-y-2 bg-slate-50/70 p-4 rounded-xl border border-slate-200">
            <div className="flex items-center justify-between text-xs">
              <label className="font-semibold text-slate-700">Nurse / Auth Coordinator Wage</label>
              <span className="font-bold text-slate-900">${hourlyWage}/hour (Loaded)</span>
            </div>
            <input
              type="range"
              min={30}
              max={85}
              step={1}
              value={hourlyWage}
              onChange={(e) => setHourlyWage(Number(e.target.value))}
              className="w-full accent-blue-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>$30/hr</span>
              <span>$55/hr</span>
              <span>$85/hr</span>
            </div>
          </div>

          {/* Slider 4: Baseline Denial Rate */}
          <div className="space-y-2 bg-slate-50/70 p-4 rounded-xl border border-slate-200">
            <div className="flex items-center justify-between text-xs">
              <label className="font-semibold text-slate-700">Current Payer Denial Rate</label>
              <span className="font-bold text-red-600">{currentDenialRate}% Initial Denials</span>
            </div>
            <input
              type="range"
              min={5}
              max={35}
              step={1}
              value={currentDenialRate}
              onChange={(e) => setCurrentDenialRate(Number(e.target.value))}
              className="w-full accent-red-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>5% (Low)</span>
              <span>18% (National Avg)</span>
              <span>35% (Severe)</span>
            </div>
          </div>

          {/* Slider 5: Average Procedure Margin */}
          <div className="space-y-2 bg-slate-50/70 p-4 rounded-xl border border-slate-200 lg:col-span-2">
            <div className="flex items-center justify-between text-xs">
              <label className="font-semibold text-slate-700">Average Procedure Net Revenue</label>
              <span className="font-bold text-slate-900">${avgProcedureRevenue.toLocaleString()} / Case</span>
            </div>
            <input
              type="range"
              min={2500}
              max={35000}
              step={500}
              value={avgProcedureRevenue}
              onChange={(e) => setAvgProcedureRevenue(Number(e.target.value))}
              className="w-full accent-blue-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400">
              <span>$2,500 (Outpatient MRI)</span>
              <span>$15,000 (Spine/Ortho)</span>
              <span>$35,000+ (TAVR/Oncology)</span>
            </div>
          </div>
        </div>

        {/* Dynamic Financial Results Showcase */}
        <div className="bg-gradient-to-br from-slate-900 to-indigo-950 rounded-2xl p-6 sm:p-8 text-white space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-4 gap-2">
            <div>
              <span className="text-[11px] font-mono uppercase tracking-wider text-cyan-400">
                Projected Annual Financial Returns
              </span>
              <h3 className="text-xl sm:text-2xl font-bold text-white mt-0.5">
                Total Annual Hospital Value: ${totalAnnualValue.toLocaleString()}
              </h3>
            </div>
            <div className="flex items-center gap-3">
              <div className="text-right">
                <div className="text-xs text-slate-400">Payback Period</div>
                <div className="text-base font-bold text-emerald-400">{paybackDays} Days</div>
              </div>
              <div className="h-8 w-px bg-slate-800" />
              <div className="text-right">
                <div className="text-xs text-slate-400">ROI Multiple</div>
                <div className="text-base font-bold text-cyan-400">{roiMultiple}x</div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {/* Metric 1 */}
            <div className="space-y-1">
              <div className="text-xs text-slate-400 flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                Administrative Hours Reclaimed
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-white">
                {annualHoursSaved.toLocaleString()}
              </div>
              <p className="text-xs text-slate-400">
                Equivalent to {(annualHoursSaved / 2080).toFixed(1)} Full-Time Staff (FTEs) refocused on patient care
              </p>
            </div>

            {/* Metric 2 */}
            <div className="space-y-1">
              <div className="text-xs text-slate-400 flex items-center gap-1.5">
                <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                Direct Labor Cost Saved
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400">
                ${annualLaborSavings.toLocaleString()}
              </div>
              <p className="text-xs text-slate-400">
                Saved from chart mining, faxing, and portal re-keying
              </p>
            </div>

            {/* Metric 3 */}
            <div className="space-y-1">
              <div className="text-xs text-slate-400 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                Revenue Preserved from Denials
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-cyan-400">
                ${revenuePreserved.toLocaleString()}
              </div>
              <p className="text-xs text-slate-400">
                Prevents {preventedDenialsPerYear.toLocaleString()} unnecessary denials with pre-submission guideline checks
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Qualitative Hospital Pain Points Solved */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold">
            <Users className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-slate-900">Physician & Staff Burnout Reversal</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Physicians average 14 hours per week on prior authorizations. AuthFlow automates the routine chart gathering, generates 3-minute peer-to-peer call briefs, and returns clinical autonomy to doctors.
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
            <FileCheck className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-slate-900">CMS-0057-F Interoperability Compliance</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Ready for CMS Prior Authorization and Interoperability Final Rule mandates (electronic FHIR API, 72-hour expedited decisions, published metrics), ensuring full Medicare Advantage accreditation.
          </p>
        </div>

        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold">
            <AlertOctagon className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-sm text-slate-900">Zero Surgical Case Cancellations</h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Eliminates eleventh-hour surgery day cancellations caused by delayed auth numbers. OR suites and infusion chairs remain booked with 100% pre-authorized coverage verified.
          </p>
        </div>
      </div>
    </div>
  );
};
