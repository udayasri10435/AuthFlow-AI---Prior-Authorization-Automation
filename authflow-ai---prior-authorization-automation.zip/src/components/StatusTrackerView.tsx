import React, { useState } from 'react';
import {
  Clock,
  CheckCircle2,
  AlertTriangle,
  FileCheck,
  Search,
  Filter,
  Send,
  Scale,
  PhoneCall,
  ChevronRight,
  ExternalLink,
  ShieldCheck,
  Building,
  User,
  Activity,
  Layers,
  Sparkles,
} from 'lucide-react';
import { PriorAuthRecord, PriorAuthStatus } from '../types/priorAuth';
import { AppealModal } from './AppealModal';
import { PeerToPeerModal } from './PeerToPeerModal';

interface StatusTrackerViewProps {
  records: PriorAuthRecord[];
  onUpdateRecord: (record: PriorAuthRecord) => void;
  onSelectForForm: (record: PriorAuthRecord) => void;
}

export const StatusTrackerView: React.FC<StatusTrackerViewProps> = ({
  records,
  onUpdateRecord,
  onSelectForForm,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [payerFilter, setPayerFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'kanban' | 'table'>('kanban');
  const [selectedRecord, setSelectedRecord] = useState<PriorAuthRecord | null>(null);

  // Modals for appeals and peer-to-peer
  const [appealModalRecord, setAppealModalRecord] = useState<PriorAuthRecord | null>(null);
  const [p2pModalRecord, setP2pModalRecord] = useState<PriorAuthRecord | null>(null);

  // Filtering
  const filteredRecords = records.filter((rec) => {
    const matchesSearch =
      rec.patient.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rec.clinical.requestedService.cptCode.includes(searchQuery) ||
      rec.patient.memberId.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus =
      statusFilter === 'all' ||
      (statusFilter === 'approved' && rec.status === 'approved') ||
      (statusFilter === 'in_review' && (rec.status === 'submitted' || rec.status === 'in_payer_review')) ||
      (statusFilter === 'denied' && (rec.status === 'denied' || rec.status === 'appealed' || rec.status === 'peer_to_peer_scheduled')) ||
      (statusFilter === 'review_needed' && rec.status === 'review_needed');

    const matchesPayer = payerFilter === 'all' || rec.patient.payerName.includes(payerFilter);

    return matchesSearch && matchesStatus && matchesPayer;
  });

  // Simulate Payer Instant Decisions for interactive demonstration
  const handleSimulateApproval = (rec: PriorAuthRecord) => {
    const authNum = `AUTH-${rec.patient.payerName.slice(0, 3).toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}-AP`;
    const validDate = new Date();
    validDate.setMonth(validDate.getMonth() + 3);

    const updated: PriorAuthRecord = {
      ...rec,
      status: 'approved',
      authorizationNumber: authNum,
      validThrough: validDate.toISOString().split('T')[0],
      updatedAt: new Date().toISOString(),
      timeline: [
        ...rec.timeline,
        {
          id: `tl-appr-${Date.now()}`,
          timestamp: new Date().toISOString(),
          title: 'Payer Authorization Approved (EDI 277)',
          description: `Payer issued official authorization code ${authNum}. Valid through ${validDate.toISOString().split('T')[0]}.`,
          type: 'payer_response',
          actor: `${rec.patient.payerName} Adjudication Engine`,
        },
      ],
    };

    onUpdateRecord(updated);
    if (selectedRecord?.id === rec.id) {
      setSelectedRecord(updated);
    }
  };

  const handleSimulateDenial = (rec: PriorAuthRecord) => {
    const updated: PriorAuthRecord = {
      ...rec,
      status: 'denied',
      denialCode: 'CARC 197 / RARC N382',
      denialReason: `Adverse Determination: Medical review determined documentation lacks evidence of conservative treatment duration under ${rec.patient.payerName} Clinical Policy Bulletin.`,
      updatedAt: new Date().toISOString(),
      timeline: [
        ...rec.timeline,
        {
          id: `tl-den-${Date.now()}`,
          timestamp: new Date().toISOString(),
          title: 'Payer Adverse Determination (Denial)',
          description: `Initial review denied under CARC 197 / RARC N382. Level 1 Appeal window active (180 days).`,
          type: 'payer_response',
          actor: `${rec.patient.payerName} Medical Director`,
        },
      ],
    };

    onUpdateRecord(updated);
    if (selectedRecord?.id === rec.id) {
      setSelectedRecord(updated);
    }
  };

  const getStatusBadge = (status: PriorAuthStatus) => {
    switch (status) {
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            Approved · Auth Issued
          </span>
        );
      case 'submitted':
      case 'in_payer_review':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-800 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
            <Clock className="w-3 h-3 text-blue-600" />
            In Payer Review
          </span>
        );
      case 'review_needed':
      case 'draft':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
            <FileCheck className="w-3 h-3 text-amber-600" />
            Review Needed
          </span>
        );
      case 'denied':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-red-800 bg-red-50 px-2 py-0.5 rounded border border-red-200">
            <AlertTriangle className="w-3 h-3 text-red-600" />
            Initial Denial (Action Needed)
          </span>
        );
      case 'appealed':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-purple-800 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
            <Scale className="w-3 h-3 text-purple-600" />
            Level 1 Appeal Pending
          </span>
        );
      case 'peer_to_peer_scheduled':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-800 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
            <PhoneCall className="w-3 h-3 text-amber-600" />
            Peer-to-Peer Scheduled
          </span>
        );
      default:
        return null;
    }
  };

  // Groupings for Kanban
  const kanbanColumns = [
    {
      id: 'col-draft',
      title: 'Review Needed / Draft',
      records: filteredRecords.filter((r) => r.status === 'review_needed' || r.status === 'draft'),
      borderColor: 'border-amber-200',
      badgeColor: 'bg-amber-100 text-amber-800',
    },
    {
      id: 'col-review',
      title: 'Submitted / In Payer Review',
      records: filteredRecords.filter((r) => r.status === 'submitted' || r.status === 'in_payer_review'),
      borderColor: 'border-blue-200',
      badgeColor: 'bg-blue-100 text-blue-800',
    },
    {
      id: 'col-approved',
      title: 'Approved (Auth # Active)',
      records: filteredRecords.filter((r) => r.status === 'approved'),
      borderColor: 'border-emerald-200',
      badgeColor: 'bg-emerald-100 text-emerald-800',
    },
    {
      id: 'col-action',
      title: 'Action Needed / Denials & Appeals',
      records: filteredRecords.filter(
        (r) =>
          r.status === 'denied' ||
          r.status === 'appealed' ||
          r.status === 'peer_to_peer_scheduled' ||
          r.status === 'additional_info_required'
      ),
      borderColor: 'border-red-200',
      badgeColor: 'bg-red-100 text-red-800',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Top Stats Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Total Active Prior Auths</div>
          <div className="text-2xl font-bold text-slate-900 mt-1">{records.length}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Memorial Hospital Health System</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">In Payer Review</div>
          <div className="text-2xl font-bold text-blue-600 mt-1">
            {records.filter((r) => r.status === 'submitted' || r.status === 'in_payer_review').length}
          </div>
          <div className="text-[11px] text-blue-600 mt-0.5">Average Turnaround: 1.2 Days</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Approved / Cleared</div>
          <div className="text-2xl font-bold text-emerald-600 mt-1">
            {records.filter((r) => r.status === 'approved').length}
          </div>
          <div className="text-[11px] text-emerald-600 mt-0.5">First-Pass Approval: 94.8%</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
          <div className="text-xs text-slate-500 font-medium">Denials & Appeals</div>
          <div className="text-2xl font-bold text-red-600 mt-1">
            {records.filter((r) => r.status === 'denied' || r.status === 'appealed' || r.status === 'peer_to_peer_scheduled').length}
          </div>
          <div className="text-[11px] text-red-500 mt-0.5">AI Appeal Overturn Rate: 88%</div>
        </div>
      </div>

      {/* Filter and Control Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Search Box */}
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search patient, Member ID, CPT, or PA ID..."
              className="w-full text-xs text-slate-800 bg-slate-50 border border-slate-300 rounded-lg pl-9 pr-3 py-2 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          {/* Filters & View Switcher */}
          <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto text-xs">
            {/* Payer Filter */}
            <select
              value={payerFilter}
              onChange={(e) => setPayerFilter(e.target.value)}
              className="text-xs text-slate-700 bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 focus:outline-none"
            >
              <option value="all">All Payers</option>
              <option value="UnitedHealthcare">UnitedHealthcare</option>
              <option value="Aetna">Aetna</option>
              <option value="Anthem">Anthem Blue Cross</option>
              <option value="Humana">Humana</option>
              <option value="Cigna">Cigna</option>
            </select>

            {/* View Mode */}
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
              <button
                onClick={() => setViewMode('kanban')}
                className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                  viewMode === 'kanban' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                Kanban
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                  viewMode === 'table' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
                }`}
              >
                Table
              </button>
            </div>
          </div>
        </div>

        {/* Status Pills Filter */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-1 text-xs">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
              statusFilter === 'all'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            All Statuses ({records.length})
          </button>
          <button
            onClick={() => setStatusFilter('review_needed')}
            className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
              statusFilter === 'review_needed'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Review Needed ({records.filter((r) => r.status === 'review_needed').length})
          </button>
          <button
            onClick={() => setStatusFilter('in_review')}
            className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
              statusFilter === 'in_review'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            In Payer Review ({records.filter((r) => r.status === 'submitted' || r.status === 'in_payer_review').length})
          </button>
          <button
            onClick={() => setStatusFilter('approved')}
            className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
              statusFilter === 'approved'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Approved ({records.filter((r) => r.status === 'approved').length})
          </button>
          <button
            onClick={() => setStatusFilter('denied')}
            className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
              statusFilter === 'denied'
                ? 'bg-slate-900 text-white'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            Denials & Appeals ({records.filter((r) => r.status === 'denied' || r.status === 'appealed' || r.status === 'peer_to_peer_scheduled').length})
          </button>
        </div>
      </div>

      {/* Main View Mode: Kanban Pipeline */}
      {viewMode === 'kanban' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-start">
          {kanbanColumns.map((col) => (
            <div key={col.id} className="bg-slate-100/70 rounded-xl p-3 border border-slate-200/80 space-y-3">
              <div className="flex items-center justify-between px-1">
                <span className="font-semibold text-xs text-slate-800">{col.title}</span>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded ${col.badgeColor}`}>
                  {col.records.length}
                </span>
              </div>

              <div className="space-y-2.5">
                {col.records.map((rec) => (
                  <div
                    key={rec.id}
                    onClick={() => setSelectedRecord(rec)}
                    className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs hover:shadow-md hover:border-blue-400 transition-all cursor-pointer space-y-2.5"
                  >
                    <div className="flex items-start justify-between gap-1">
                      <span className="text-[11px] font-mono font-semibold text-slate-500">
                        {rec.id}
                      </span>
                      {rec.clinical.requestedService.urgency.includes('Urgent') && (
                        <span className="text-[10px] font-bold text-red-700 bg-red-50 border border-red-200 px-1.5 py-0.2 rounded">
                          72h Expedited
                        </span>
                      )}
                    </div>

                    <div>
                      <h4 className="font-bold text-xs text-slate-900">{rec.patient.fullName}</h4>
                      <p className="text-[11px] text-slate-600 line-clamp-1 mt-0.5">
                        {rec.clinical.requestedService.serviceName}
                      </p>
                    </div>

                    <div className="text-[11px] text-slate-500 space-y-0.5 pt-1 border-t border-slate-100">
                      <div className="flex items-center justify-between">
                        <span>Payer:</span>
                        <strong className="text-slate-700 font-medium">{rec.patient.payerName}</strong>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>CPT:</span>
                        <span className="font-mono text-blue-700 font-semibold">
                          {rec.clinical.requestedService.cptCode}
                        </span>
                      </div>
                    </div>

                    {/* Status badge */}
                    <div className="pt-1">{getStatusBadge(rec.status)}</div>

                    {/* Quick indicator if approved or denied */}
                    {rec.authorizationNumber && (
                      <div className="bg-emerald-50 p-1.5 rounded border border-emerald-200 text-[10px] text-emerald-800 font-mono font-bold">
                        Auth #: {rec.authorizationNumber}
                      </div>
                    )}
                    {rec.denialCode && (
                      <div className="bg-red-50 p-1.5 rounded border border-red-200 text-[10px] text-red-800 font-medium">
                        {rec.denialCode} · Tap to Appeal
                      </div>
                    )}
                  </div>
                ))}

                {col.records.length === 0 && (
                  <div className="text-center py-8 text-xs text-slate-400 border border-dashed border-slate-300 rounded-lg">
                    No requests in this stage
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Main View Mode: Tabular List */}
      {viewMode === 'table' && (
        <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-700 font-semibold border-b border-slate-200">
              <tr>
                <th className="p-3">PA ID</th>
                <th className="p-3">Patient</th>
                <th className="p-3">Payer</th>
                <th className="p-3">Requested Service (CPT)</th>
                <th className="p-3">Ordering Provider</th>
                <th className="p-3">Status</th>
                <th className="p-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredRecords.map((rec) => (
                <tr
                  key={rec.id}
                  onClick={() => setSelectedRecord(rec)}
                  className="hover:bg-slate-50/80 cursor-pointer transition-colors"
                >
                  <td className="p-3 font-mono font-semibold text-slate-800">{rec.id}</td>
                  <td className="p-3">
                    <div className="font-semibold text-slate-900">{rec.patient.fullName}</div>
                    <div className="text-[11px] text-slate-400">DOB: {rec.patient.dob}</div>
                  </td>
                  <td className="p-3 font-medium text-slate-700">{rec.patient.payerName}</td>
                  <td className="p-3">
                    <div className="text-slate-800 line-clamp-1">{rec.clinical.requestedService.serviceName}</div>
                    <span className="font-mono text-blue-700 font-semibold">
                      CPT {rec.clinical.requestedService.cptCode}
                    </span>
                  </td>
                  <td className="p-3 text-slate-600">{rec.patient.orderingProvider.name}</td>
                  <td className="p-3">{getStatusBadge(rec.status)}</td>
                  <td className="p-3 text-right">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedRecord(rec);
                      }}
                      className="text-xs font-semibold text-blue-600 hover:text-blue-800"
                    >
                      View Details &rarr;
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Selected Record Detail Drawer / Modal */}
      {selectedRecord && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-4xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600/30 text-blue-400 border border-blue-500/30 flex items-center justify-center font-mono font-bold text-xs">
                  {selectedRecord.id.split('-').pop()}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-base text-white">{selectedRecord.patient.fullName}</h3>
                    {getStatusBadge(selectedRecord.status)}
                  </div>
                  <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                    <span>{selectedRecord.patient.payerName}</span>
                    <span>·</span>
                    <span>Member ID: {selectedRecord.patient.memberId}</span>
                    <span>·</span>
                    <span>PA ID: {selectedRecord.id}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setSelectedRecord(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
              >
                &times;
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-800">
              {/* If Approved Banner */}
              {selectedRecord.authorizationNumber && (
                <div className="bg-emerald-50 border border-emerald-300 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="text-xs font-bold text-emerald-900 uppercase">
                      Official Payer Prior Authorization Issued
                    </div>
                    <div className="text-lg font-mono font-bold text-emerald-900 mt-0.5">
                      {selectedRecord.authorizationNumber}
                    </div>
                    <div className="text-xs text-emerald-700 mt-0.5">
                      Valid Through: {selectedRecord.validThrough || '90 Days'} · Covered Units: {selectedRecord.clinical.requestedService.units}
                    </div>
                  </div>
                  <button
                    onClick={() => window.print()}
                    className="text-xs font-semibold text-emerald-800 bg-white border border-emerald-300 hover:bg-emerald-100 px-3.5 py-2 rounded-lg transition-colors"
                  >
                    Download Official Authorization Notice
                  </button>
                </div>
              )}

              {/* If Denied Banner with Action Buttons */}
              {selectedRecord.status === 'denied' && (
                <div className="bg-red-50 border border-red-300 rounded-xl p-4 space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="text-xs font-bold text-red-900 uppercase flex items-center gap-1.5">
                        <AlertTriangle className="w-4 h-4 text-red-600" />
                        Payer Initial Adverse Determination (Denial)
                      </div>
                      <div className="text-xs font-semibold text-red-800 mt-1">
                        Reason: {selectedRecord.denialReason}
                      </div>
                      <div className="text-[11px] text-red-600 font-mono mt-0.5">
                        Denial Code: {selectedRecord.denialCode || 'CARC 197 / RARC N382'}
                      </div>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-red-200">
                    <button
                      onClick={() => {
                        setAppealModalRecord(selectedRecord);
                      }}
                      className="flex items-center gap-1.5 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-xs font-semibold px-4 py-2 rounded-lg shadow-sm transition-all cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-rose-200" />
                      <span>Generate AI Appeal Dossier (Level 1)</span>
                    </button>

                    <button
                      onClick={() => {
                        setP2pModalRecord(selectedRecord);
                      }}
                      className="flex items-center gap-1.5 bg-white border border-amber-300 hover:bg-amber-50 text-amber-900 text-xs font-semibold px-4 py-2 rounded-lg transition-colors cursor-pointer"
                    >
                      <PhoneCall className="w-3.5 h-3.5 text-amber-700" />
                      <span>Physician Peer-to-Peer 3-Min Call Brief</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Service & Clinical Details Card */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-2">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Requested Procedure & Setting
                  </h4>
                  <div className="text-xs space-y-1.5">
                    <div>
                      <span className="text-slate-500">Service:</span>{' '}
                      <strong className="text-slate-900">
                        {selectedRecord.clinical.requestedService.serviceName}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-500">CPT / HCPCS:</span>{' '}
                      <span className="font-mono font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded">
                        {selectedRecord.clinical.requestedService.cptCode}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500">Facility:</span>{' '}
                      <span className="text-slate-800">
                        {selectedRecord.patient.orderingProvider.facilityName}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500">Setting:</span>{' '}
                      <span className="text-slate-800">
                        {selectedRecord.clinical.requestedService.serviceSetting}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-2">
                  <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                    Ordering Physician & Clinic
                  </h4>
                  <div className="text-xs space-y-1.5">
                    <div>
                      <span className="text-slate-500">Doctor:</span>{' '}
                      <strong className="text-slate-900">
                        {selectedRecord.patient.orderingProvider.name}
                      </strong>
                    </div>
                    <div>
                      <span className="text-slate-500">Specialty:</span>{' '}
                      <span className="text-slate-800">
                        {selectedRecord.patient.orderingProvider.specialty}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500">NPI:</span>{' '}
                      <span className="font-mono text-slate-700">
                        {selectedRecord.patient.orderingProvider.npi}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500">Contact Phone:</span>{' '}
                      <span className="text-slate-800">
                        {selectedRecord.patient.orderingProvider.contactPhone}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Full Chronological Timeline */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-blue-600" />
                  Audit Trail & Clearinghouse Transaction History
                </h4>
                <div className="border-l-2 border-slate-200 pl-4 space-y-3 ml-2">
                  {selectedRecord.timeline.map((event) => (
                    <div key={event.id} className="relative space-y-0.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-blue-600 absolute -left-[21px] top-1 border-2 border-white" />
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-900">{event.title}</span>
                        <span className="text-[10px] text-slate-400">
                          {new Date(event.timestamp).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}{' '}
                          · {new Date(event.timestamp).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600">{event.description}</p>
                      <div className="text-[10px] text-slate-400">Actor: {event.actor}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Testing / Simulation Handlers for Demo */}
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <div className="text-xs font-bold text-slate-700 uppercase">
                  Workflow Simulation Controls
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => handleSimulateApproval(selectedRecord)}
                    className="text-xs font-semibold text-emerald-800 bg-emerald-100 hover:bg-emerald-200 px-3 py-1.5 rounded-md transition-colors cursor-pointer"
                  >
                    Simulate Payer Approval (277 Active Auth)
                  </button>
                  <button
                    onClick={() => handleSimulateDenial(selectedRecord)}
                    className="text-xs font-semibold text-red-800 bg-red-100 hover:bg-red-200 px-3 py-1.5 rounded-md transition-colors cursor-pointer"
                  >
                    Simulate Payer Denial (Test AI Appeal)
                  </button>
                  <button
                    onClick={() => {
                      onSelectForForm(selectedRecord);
                      setSelectedRecord(null);
                    }}
                    className="text-xs font-semibold text-blue-800 bg-blue-100 hover:bg-blue-200 px-3 py-1.5 rounded-md transition-colors cursor-pointer"
                  >
                    Open Payer Form / EDI 278 View
                  </button>
                </div>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex items-center justify-between">
              <span className="text-xs text-slate-500">
                Created: {new Date(selectedRecord.createdAt).toLocaleDateString()}
              </span>
              <button
                onClick={() => setSelectedRecord(null)}
                className="text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-lg"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Appeal Dossier Modal */}
      {appealModalRecord && (
        <AppealModal
          record={appealModalRecord}
          onClose={() => setAppealModalRecord(null)}
          onAppealSubmitted={(updated) => {
            onUpdateRecord(updated);
            if (selectedRecord?.id === updated.id) setSelectedRecord(updated);
          }}
        />
      )}

      {/* Peer-to-Peer Briefing Modal */}
      {p2pModalRecord && (
        <PeerToPeerModal
          record={p2pModalRecord}
          onClose={() => setP2pModalRecord(null)}
          onScheduled={(updated) => {
            onUpdateRecord(updated);
            if (selectedRecord?.id === updated.id) setSelectedRecord(updated);
          }}
        />
      )}
    </div>
  );
};
