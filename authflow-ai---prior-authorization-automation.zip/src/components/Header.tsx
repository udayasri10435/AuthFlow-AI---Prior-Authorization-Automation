import React from 'react';
import {
  FileCheck2,
  FileSpreadsheet,
  BarChart3,
  Clock,
  Sparkles,
  ShieldCheck,
  Building2,
  Activity,
  PlusCircle,
} from 'lucide-react';

interface HeaderProps {
  activeTab: 'intake' | 'form' | 'tracker' | 'roi';
  setActiveTab: (tab: 'intake' | 'form' | 'tracker' | 'roi') => void;
  activePACount: number;
  onNewIntake: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  activePACount,
  onNewIntake,
}) => {
  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
      {/* Top hospital banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-blue-600 to-indigo-600 flex items-center justify-center shadow-lg shadow-blue-900/30">
              <FileCheck2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-semibold text-lg tracking-tight text-white">AuthFlow AI</span>
                <span className="text-[11px] font-medium tracking-wide uppercase px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  Hospital Prior Auth Suite
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span className="flex items-center gap-1">
                  <Building2 className="w-3 h-3 text-slate-400" />
                  Memorial Health Network
                </span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="flex items-center gap-1 text-emerald-400">
                  <Activity className="w-3 h-3" />
                  EHR & EDI 278 Connected
                </span>
              </div>
            </div>
          </div>

          {/* Quick Metrics & Actions */}
          <div className="flex items-center gap-3">
            <div className="hidden md:flex items-center gap-4 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700/60 text-xs">
              <div className="flex items-center gap-1.5 text-slate-300">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>Active Pipeline:</span>
                <strong className="text-white font-semibold">{activePACount} Requests</strong>
              </div>
              <span className="text-slate-600">|</span>
              <div className="flex items-center gap-1.5 text-slate-300">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Approval Rate:</span>
                <strong className="text-emerald-400 font-semibold">94.8%</strong>
              </div>
            </div>

            <button
              onClick={onNewIntake}
              className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-semibold px-3.5 py-2 rounded-lg shadow-sm transition-all focus:outline-none focus:ring-2 focus:ring-blue-400 focus:ring-offset-2 focus:ring-offset-slate-900"
            >
              <PlusCircle className="w-4 h-4" />
              <span>New Clinical Intake</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 border-t border-slate-800/80 pt-1 pb-2 overflow-x-auto text-xs font-medium">
          <button
            onClick={() => setActiveTab('intake')}
            className={`flex items-center gap-2 px-3 py-2 rounded-md transition-colors ${
              activeTab === 'intake'
                ? 'bg-slate-800 text-white font-semibold border border-slate-700'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>AI Clinical Extraction</span>
          </button>

          <button
            onClick={() => setActiveTab('form')}
            className={`flex items-center gap-2 px-3 py-2 rounded-md transition-colors ${
              activeTab === 'form'
                ? 'bg-slate-800 text-white font-semibold border border-slate-700'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-blue-400" />
            <span>Payer Form & EDI 278</span>
          </button>

          <button
            onClick={() => setActiveTab('tracker')}
            className={`flex items-center gap-2 px-3 py-2 rounded-md transition-colors ${
              activeTab === 'tracker'
                ? 'bg-slate-800 text-white font-semibold border border-slate-700'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>Status Tracker & Appeals</span>
          </button>

          <button
            onClick={() => setActiveTab('roi')}
            className={`flex items-center gap-2 px-3 py-2 rounded-md transition-colors ${
              activeTab === 'roi'
                ? 'bg-slate-800 text-white font-semibold border border-slate-700'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5 text-emerald-400" />
            <span>Hospital ROI & Business Case</span>
          </button>
        </div>
      </div>
    </header>
  );
};
