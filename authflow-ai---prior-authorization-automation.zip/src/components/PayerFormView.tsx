import React, { useState } from 'react';
import {
  FileSpreadsheet,
  CheckCircle2,
  Send,
  Building,
  ShieldCheck,
  FileCode,
  PenTool,
  Clock,
  Printer,
  Sparkles,
  AlertCircle,
} from 'lucide-react';
import { PriorAuthRecord } from '../types/priorAuth';

interface PayerFormViewProps {
  currentRecord: PriorAuthRecord;
  onUpdateRecord: (updated: PriorAuthRecord) => void;
  onNavigateToTracker: () => void;
}

export const PayerFormView: React.FC<PayerFormViewProps> = ({
  currentRecord,
  onUpdateRecord,
  onNavigateToTracker,
}) => {
  const [formFields, setFormFields] = useState(currentRecord.payerFormFields);
  const [viewMode, setViewMode] = useState<'form' | 'edi278'>('form');
  const [isSigned, setIsSigned] = useState<boolean>(true);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submissionSuccess, setSubmissionSuccess] = useState<boolean>(false);
  const [generatedEdiTxId, setGeneratedEdiTxId] = useState<string>('');

  const handleFieldChange = (field: string, value: string) => {
    setFormFields((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleSubmitToPayer = async () => {
    setIsSubmitting(true);
    setSubmissionSuccess(false);

    // Simulate EDI 278 Clearinghouse Transaction transmission
    await new Promise((r) => setTimeout(r, 1400));

    const txId = `EDI278-${currentRecord.patient.payerName.slice(0, 3).toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`;
    setGeneratedEdiTxId(txId);

    const updatedRecord: PriorAuthRecord = {
      ...currentRecord,
      payerFormFields: formFields,
      status: 'submitted',
      edi278TransactionId: txId,
      updatedAt: new Date().toISOString(),
      timeline: [
        ...currentRecord.timeline,
        {
          id: `tl-sub-${Date.now()}`,
          timestamp: new Date().toISOString(),
          title: 'EDI 278 Prior Authorization Transmitted',
          description: `Transmitted to ${currentRecord.patient.payerName} clearinghouse gateway (Transaction ID: ${txId})`,
          type: 'submission',
          actor: 'AuthFlow EDI Gateway',
        },
      ],
    };

    onUpdateRecord(updatedRecord);
    setIsSubmitting(false);
    setSubmissionSuccess(true);
  };

  // Generate real EDI 278 X12 schema string based on record
  const edi278Text = `ISA*00*          *00*          *ZZ*AUTHFLOW_AI    *ZZ*${currentRecord.patient.payerName.slice(0, 8).toUpperCase().padEnd(15, ' ')}*${new Date().toISOString().slice(2, 10).replace(/-/g, '')}*1200*^*00501*000000042*0*P*:~
GS*HI*AUTHFLOW*${currentRecord.patient.payerName.slice(0, 8).toUpperCase()}*${new Date().toISOString().slice(0, 10).replace(/-/g, '')}*1200*1*X*005010X217~
ST*278*0001*005010X217~
BHT*0007*13*REQ-${currentRecord.id}*${new Date().toISOString().slice(0, 10).replace(/-/g, '')}*1200*RQ~
HL*1**20*1~
NM1*X3*2*${currentRecord.patient.payerName.toUpperCase()}*****PI*${formFields.box4_insuredId}~
HL*2*1*21*1~
NM1*1P*1*${currentRecord.patient.orderingProvider.name.toUpperCase()}*****XX*${currentRecord.patient.orderingProvider.npi}~
HL*3*2*22*1~
NM1*IL*1*${currentRecord.patient.fullName.toUpperCase()}*****MI*${formFields.box4_insuredId}~
DMG*D8*${currentRecord.patient.dob.replace(/-/g, '')}*${currentRecord.patient.gender === 'Male' ? 'M' : 'F'}~
HL*4*3*EV*0~
UM*HS*I*2*${currentRecord.clinical.requestedService.serviceSetting.includes('Inpatient') ? '21' : '24'}*B~
DTP*472*D8*${currentRecord.clinical.requestedService.anticipatedDate.replace(/-/g, '')}~
HI*BK:${currentRecord.clinical.primaryDiagnosis.code.replace('.', '')}${currentRecord.clinical.secondaryDiagnoses.map((s) => `*BF:${s.code.replace('.', '')}`).join('')}~
SV1*HC:${currentRecord.clinical.requestedService.cptCode}*${formFields.box24_chargesEstimated.replace(/[$,]/g, '')}*UN*${currentRecord.clinical.requestedService.units}***1~
PWK*OZ*EL*Letter of Medical Necessity Attached via X12 Attachment~
SE*16*0001~
GE*1*1~
IEA*1*000000042~`;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-6">
      {/* Title & Status Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold uppercase text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-blue-600" />
              AI Form Completion Engine
            </span>
            <span className="text-xs text-slate-500">·</span>
            <span className="text-xs font-mono text-slate-600">ID: {currentRecord.id}</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 mt-1">
            Payer Prior Authorization Form & EDI 278 Transmission
          </h1>
          <p className="text-xs text-slate-500">
            Auto-populated from EHR extraction. Clinicians can review, override fields, and submit electronic 278 transactions directly to payer clearinghouses.
          </p>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Dual Mode Switcher */}
          <div className="flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200 text-xs">
            <button
              onClick={() => setViewMode('form')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
                viewMode === 'form' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-blue-600" />
              <span>CMS-1500 Form</span>
            </button>
            <button
              onClick={() => setViewMode('edi278')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-medium transition-colors ${
                viewMode === 'edi278' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <FileCode className="w-3.5 h-3.5 text-indigo-600" />
              <span>Electronic EDI 278</span>
            </button>
          </div>

          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 text-xs text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 px-3 py-2 rounded-lg transition-colors"
          >
            <Printer className="w-3.5 h-3.5 text-slate-600" />
            <span className="hidden sm:inline">Print Form</span>
          </button>
        </div>
      </div>

      {/* Submission Success Alert */}
      {submissionSuccess && (
        <div className="bg-emerald-50 border border-emerald-300 rounded-xl p-5 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
              <CheckCircle2 className="w-5 h-5 text-emerald-600" />
              <span>Prior Authorization Submitted Successfully via EDI 278!</span>
            </div>
            <button
              onClick={onNavigateToTracker}
              className="text-xs font-semibold text-emerald-800 bg-white border border-emerald-300 hover:bg-emerald-100 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
            >
              Track in Pipeline &rarr;
            </button>
          </div>
          <p className="text-xs text-emerald-800">
            Transmitted to <strong>{currentRecord.patient.payerName}</strong>. Clearinghouse 277 Acknowledgement received with Transaction ID: <span className="font-mono font-bold">{generatedEdiTxId}</span>. Expected payer turnaround: {currentRecord.clinical.requestedService.urgency.includes('Urgent') ? '72 Hours' : '5-10 Days'}.
          </p>
        </div>
      )}

      {/* View Mode 1: CMS-1500 / Universal Form Layout */}
      {viewMode === 'form' && (
        <div className="bg-white rounded-2xl border-2 border-red-700/80 shadow-md overflow-hidden">
          {/* Header of CMS 1500 Form */}
          <div className="bg-red-50 border-b border-red-200 px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <div className="text-[10px] font-bold text-red-700 uppercase tracking-widest">
                HEALTH INSURANCE CLAIM & PRIOR AUTHORIZATION REQUEST FORM
              </div>
              <h2 className="text-sm font-bold text-slate-900">
                STANDARD UNIFORM PRIOR AUTHORIZATION FORM (CMS-1500 LAYOUT)
              </h2>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="bg-emerald-100 text-emerald-800 font-semibold px-2 py-0.5 rounded text-[11px] flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                All 12 Core Fields Auto-Filled
              </span>
            </div>
          </div>

          {/* Form Content */}
          <div className="p-6 space-y-6">
            {/* Row 1: Payer & Patient ID */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-b border-slate-200 pb-4">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-red-800 uppercase">
                  1. Payer Name & Program
                </label>
                <input
                  type="text"
                  value={formFields.box1_payerName}
                  onChange={(e) => handleFieldChange('box1_payerName', e.target.value)}
                  className="w-full text-xs font-semibold text-slate-800 bg-slate-50 border border-slate-300 rounded p-2 focus:bg-white focus:ring-1 focus:ring-red-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-red-800 uppercase">
                  1a. Insured's ID / Member ID
                </label>
                <input
                  type="text"
                  value={formFields.box4_insuredId}
                  onChange={(e) => handleFieldChange('box4_insuredId', e.target.value)}
                  className="w-full text-xs font-mono font-semibold text-slate-800 bg-slate-50 border border-slate-300 rounded p-2 focus:bg-white focus:ring-1 focus:ring-red-600"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-red-800 uppercase">
                  11. Group Number
                </label>
                <input
                  type="text"
                  value={formFields.box5_groupNumber}
                  onChange={(e) => handleFieldChange('box5_groupNumber', e.target.value)}
                  className="w-full text-xs font-mono text-slate-800 bg-slate-50 border border-slate-300 rounded p-2 focus:bg-white focus:ring-1 focus:ring-red-600"
                />
              </div>
            </div>

            {/* Row 2: Patient Demographics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 border-b border-slate-200 pb-4">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-red-800 uppercase">
                  2. Patient's Full Name (Last, First, Middle)
                </label>
                <input
                  type="text"
                  value={formFields.box2_patientName}
                  onChange={(e) => handleFieldChange('box2_patientName', e.target.value)}
                  className="w-full text-xs font-semibold text-slate-800 bg-slate-50 border border-slate-300 rounded p-2 focus:bg-white"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-red-800 uppercase">
                  3. Patient's Birth Date & Gender
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="date"
                    value={formFields.box3_patientDob}
                    onChange={(e) => handleFieldChange('box3_patientDob', e.target.value)}
                    className="w-full text-xs text-slate-800 bg-slate-50 border border-slate-300 rounded p-2 focus:bg-white"
                  />
                  <input
                    type="text"
                    value={currentRecord.patient.gender}
                    readOnly
                    className="w-full text-xs text-slate-800 bg-slate-100 border border-slate-300 rounded p-2"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-red-800 uppercase">
                  14. Date of Current Illness / Injury
                </label>
                <input
                  type="date"
                  value={formFields.box14_dateOfCurrentIllness}
                  onChange={(e) => handleFieldChange('box14_dateOfCurrentIllness', e.target.value)}
                  className="w-full text-xs text-slate-800 bg-slate-50 border border-slate-300 rounded p-2 focus:bg-white"
                />
              </div>
            </div>

            {/* Row 3: Diagnoses (Box 21) */}
            <div className="space-y-2 border-b border-slate-200 pb-4">
              <div className="flex items-center justify-between">
                <label className="text-[11px] font-bold text-red-800 uppercase">
                  21. Diagnosis or Nature of Illness or Injury (ICD-10-CM Codes)
                </label>
                <span className="text-[11px] text-slate-500">Cross-referenced against Clinical Notes</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <div className="bg-slate-50 p-2.5 rounded border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-500 uppercase">A. Primary Diagnosis</span>
                  <div className="font-mono font-bold text-blue-700 text-xs mt-0.5">
                    {currentRecord.clinical.primaryDiagnosis.code}
                  </div>
                  <div className="text-[11px] text-slate-600 line-clamp-1 mt-0.5">
                    {currentRecord.clinical.primaryDiagnosis.description}
                  </div>
                </div>

                {currentRecord.clinical.secondaryDiagnoses.map((sec, i) => (
                  <div key={i} className="bg-slate-50 p-2.5 rounded border border-slate-200">
                    <span className="text-[10px] font-bold text-slate-500 uppercase">
                      {String.fromCharCode(66 + i)}. Secondary Diagnosis
                    </span>
                    <div className="font-mono font-semibold text-slate-800 text-xs mt-0.5">
                      {sec.code}
                    </div>
                    <div className="text-[11px] text-slate-600 line-clamp-1 mt-0.5">
                      {sec.description}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Row 4: Service Line (Box 24 CPT) */}
            <div className="space-y-2 border-b border-slate-200 pb-4">
              <label className="text-[11px] font-bold text-red-800 uppercase">
                24. Service Lines, Procedures, Services, or Supplies (CPT/HCPCS)
              </label>
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left border border-slate-200">
                  <thead className="bg-slate-100 text-slate-700 text-[10px] uppercase font-bold">
                    <tr>
                      <th className="p-2 border border-slate-200">Date of Service</th>
                      <th className="p-2 border border-slate-200">Place of Service</th>
                      <th className="p-2 border border-slate-200">CPT / HCPCS Code</th>
                      <th className="p-2 border border-slate-200">Modifier</th>
                      <th className="p-2 border border-slate-200">Diagnosis Pointer</th>
                      <th className="p-2 border border-slate-200">Units</th>
                      <th className="p-2 border border-slate-200">Estimated Charges</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="bg-white">
                      <td className="p-2 border border-slate-200 font-mono">
                        {currentRecord.clinical.requestedService.anticipatedDate}
                      </td>
                      <td className="p-2 border border-slate-200">
                        {formFields.box24_placeOfService}
                      </td>
                      <td className="p-2 border border-slate-200 font-mono font-bold text-blue-700">
                        {currentRecord.clinical.requestedService.cptCode}
                      </td>
                      <td className="p-2 border border-slate-200 font-mono">RT / 50</td>
                      <td className="p-2 border border-slate-200 font-mono font-bold">A</td>
                      <td className="p-2 border border-slate-200 font-mono">
                        {currentRecord.clinical.requestedService.units}
                      </td>
                      <td className="p-2 border border-slate-200 font-mono font-semibold text-slate-800">
                        {formFields.box24_chargesEstimated}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Row 5: Facility, Billing Provider, and Physician Signature */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-red-800 uppercase">
                  32. Service Facility Location
                </label>
                <textarea
                  rows={3}
                  value={formFields.box32_serviceFacilityLocation}
                  onChange={(e) => handleFieldChange('box32_serviceFacilityLocation', e.target.value)}
                  className="w-full text-xs text-slate-800 bg-slate-50 border border-slate-300 rounded p-2 focus:bg-white resize-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-red-800 uppercase">
                  33. Billing Provider & NPI
                </label>
                <textarea
                  rows={3}
                  value={formFields.box33_billingProviderInfo}
                  onChange={(e) => handleFieldChange('box33_billingProviderInfo', e.target.value)}
                  className="w-full text-xs text-slate-800 bg-slate-50 border border-slate-300 rounded p-2 focus:bg-white resize-none"
                />
              </div>

              <div className="space-y-2 bg-slate-50 p-3 rounded-lg border border-slate-200">
                <div className="flex items-center justify-between">
                  <label className="text-[11px] font-bold text-red-800 uppercase">
                    31. Physician Attestation & Signature
                  </label>
                  <button
                    onClick={() => setIsSigned(!isSigned)}
                    className="text-[10px] text-blue-600 font-semibold underline cursor-pointer"
                  >
                    {isSigned ? 'Remove' : 'Sign Form'}
                  </button>
                </div>

                {isSigned ? (
                  <div className="p-2 bg-emerald-50 border border-emerald-300 rounded text-center space-y-1">
                    <div className="font-serif italic font-bold text-sm text-slate-800">
                      {currentRecord.patient.orderingProvider.name}
                    </div>
                    <div className="text-[10px] text-emerald-800 font-semibold flex items-center justify-center gap-1">
                      <ShieldCheck className="w-3 h-3 text-emerald-600" />
                      Digitally Verified · {formFields.box31_physicianSignatureDate}
                    </div>
                  </div>
                ) : (
                  <div className="p-3 text-center text-xs text-slate-400 border border-dashed border-slate-300 rounded">
                    Click to sign form digitally
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Form Actions Footer */}
          <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="text-xs text-slate-500 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Conforms to HIPAA Title II & WEDI Prior Authorization Best Practices</span>
            </div>

            <button
              onClick={handleSubmitToPayer}
              disabled={isSubmitting || !isSigned}
              className="flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 text-white text-xs font-semibold px-5 py-2.5 rounded-lg shadow-sm transition-all cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                  <span>Transmitting EDI 278 to Clearinghouse...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Submit Electronic Prior Auth via EDI 278</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* View Mode 2: Electronic EDI 278 X12 View */}
      {viewMode === 'edi278' && (
        <div className="bg-slate-900 rounded-2xl border border-slate-800 text-white shadow-xl overflow-hidden space-y-4 p-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <FileCode className="w-4 h-4 text-cyan-400" />
                ANSI ASC X12N 278 (005010X217) Prior Authorization Request
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Machine-to-machine electronic healthcare review transaction submitted to Payer Clearinghouse
              </p>
            </div>
            <span className="text-[11px] font-mono text-cyan-400 bg-cyan-950/80 px-2 py-0.5 rounded border border-cyan-800">
              CAQH CORE Phase IV Compliant
            </span>
          </div>

          <div className="bg-black/60 rounded-xl p-4 font-mono text-xs text-emerald-400 leading-relaxed overflow-x-auto border border-slate-800">
            <pre className="whitespace-pre">{edi278Text}</pre>
          </div>

          <div className="flex items-center justify-between pt-2">
            <span className="text-xs text-slate-400">
              Payload size: {edi278Text.length} bytes · Validated against standard X12 syntax
            </span>
            <button
              onClick={handleSubmitToPayer}
              disabled={isSubmitting || !isSigned}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-semibold px-4 py-2 rounded-lg transition-colors cursor-pointer"
            >
              {isSubmitting ? (
                <span>Transmitting...</span>
              ) : (
                <>
                  <Send className="w-3.5 h-3.5" />
                  <span>Transmit EDI 278 Payload</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
