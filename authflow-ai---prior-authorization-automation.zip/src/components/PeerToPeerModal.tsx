import React, { useState } from 'react';
import {
  X,
  PhoneCall,
  Sparkles,
  CheckCircle2,
  Clock,
  Printer,
  Copy,
  ShieldAlert,
} from 'lucide-react';
import { PriorAuthRecord, PeerToPeerBrief } from '../types/priorAuth';
import { generatePeerToPeerBrief } from '../services/api';

interface PeerToPeerModalProps {
  record: PriorAuthRecord;
  onClose: () => void;
  onScheduled: (updatedRecord: PriorAuthRecord) => void;
}

export const PeerToPeerModal: React.FC<PeerToPeerModalProps> = ({
  record,
  onClose,
  onScheduled,
}) => {
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [brief, setBrief] = useState<PeerToPeerBrief | null>(record.peerToPeerBrief || null);
  const [copied, setCopied] = useState<boolean>(false);

  const handleGenerateBrief = async () => {
    setIsGenerating(true);
    try {
      const generated = await generatePeerToPeerBrief(
        record,
        record.denialReason || 'Payer medical review denial'
      );
      setBrief(generated);
    } catch (err) {
      console.error('Failed to generate P2P brief:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleMarkScheduled = () => {
    const updated: PriorAuthRecord = {
      ...record,
      status: 'peer_to_peer_scheduled',
      peerToPeerBrief: brief || undefined,
      updatedAt: new Date().toISOString(),
      timeline: [
        ...record.timeline,
        {
          id: `tl-p2p-${Date.now()}`,
          timestamp: new Date().toISOString(),
          title: 'Physician Peer-to-Peer Review Scheduled',
          description: `Call briefing generated for ${record.patient.orderingProvider.name} with ${record.patient.payerName} Medical Director.`,
          type: 'appeal',
          actor: 'Peer-to-Peer Coordinator',
        },
      ],
    };
    onScheduled(updated);
    onClose();
  };

  const handleCopy = () => {
    if (!brief) return;
    const text = `30-SECOND ELEVATOR PITCH:\n${brief.elevatorPitch}\n\nOBJECTIVE DATA:\n${brief.objectiveDataHighlights.join('\n')}\n\nCLOSING SCRIPT:\n${brief.closingDemandScript}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-3xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center">
              <PhoneCall className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <span>Physician Peer-to-Peer 3-Minute Call Briefing</span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800">
                  Rapid Overturn Prep
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Prepared for {record.patient.orderingProvider.name} · {record.patient.payerName} Medical Director Review
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-800">
          {!brief && (
            <div className="text-center py-8 space-y-4">
              <div className="w-12 h-12 rounded-full bg-amber-50 text-amber-600 border border-amber-200 flex items-center justify-center mx-auto">
                <Clock className="w-6 h-6" />
              </div>
              <div className="max-w-md mx-auto space-y-1">
                <h4 className="font-bold text-slate-900 text-sm">
                  Generate Rapid 3-Minute Peer-to-Peer Cheat Sheet
                </h4>
                <p className="text-xs text-slate-500">
                  Distills the chart into bulletproof clinical data points, objective MRI/lab numbers, and direct counter-questions to secure verbal authorization on the call.
                </p>
              </div>
              <button
                onClick={handleGenerateBrief}
                disabled={isGenerating}
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 text-white font-semibold text-xs px-5 py-2.5 rounded-lg shadow-sm transition-all cursor-pointer inline-flex items-center gap-2"
              >
                {isGenerating ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                    <span>Analyzing Chart & Formulating P2P Strategy...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-cyan-300" />
                    <span>Generate Peer-to-Peer Brief</span>
                  </>
                )}
              </button>
            </div>
          )}

          {brief && (
            <div className="space-y-5">
              {/* 30-Second Elevator Pitch */}
              <div className="bg-amber-50/80 border border-amber-200 rounded-xl p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-amber-900 uppercase tracking-wider flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-amber-700" />
                    30-Second Opening Elevator Pitch (Read verbatim when call connects)
                  </h4>
                  <span className="text-[10px] font-mono font-semibold bg-amber-100 text-amber-800 px-2 py-0.5 rounded">
                    ~30 sec
                  </span>
                </div>
                <p className="text-xs font-medium text-slate-900 leading-relaxed bg-white p-3 rounded-lg border border-amber-200/60">
                  "{brief.elevatorPitch}"
                </p>
              </div>

              {/* Objective Data Trap */}
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <ShieldAlert className="w-3.5 h-3.5 text-blue-600" />
                  Objective Data Highlights (Uncontestable Medical Facts)
                </h4>
                <div className="grid grid-cols-1 gap-2">
                  {brief.objectiveDataHighlights.map((hl, idx) => (
                    <div
                      key={idx}
                      className="bg-white p-2.5 rounded border border-slate-200 text-xs text-slate-800 flex items-start gap-2"
                    >
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                      <span>{hl}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Rebuttals to Common Medical Director Questions */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  Rebuttals to Medical Director Pushback
                </h4>
                <div className="space-y-2.5">
                  {brief.rebuttals.map((reb, idx) => (
                    <div key={idx} className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs space-y-1.5 text-xs">
                      <div className="font-bold text-red-900">
                        Payer Objection: "{reb.payerQuestion}"
                      </div>
                      <div className="text-slate-800 bg-slate-50 p-2.5 rounded border border-slate-200 font-medium leading-relaxed">
                        Recommended Response: "{reb.recommendedAnswer}"
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Closing Script */}
              <div className="bg-emerald-50 border border-emerald-300 rounded-xl p-4 space-y-1.5">
                <h4 className="text-xs font-bold text-emerald-900 uppercase tracking-wider">
                  Closing Demand for Verbal Approval #
                </h4>
                <p className="text-xs text-emerald-900 font-medium italic">
                  "{brief.closingDemandScript}"
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={onClose}
            className="text-xs text-slate-600 hover:text-slate-900 px-3 py-2 rounded-lg"
          >
            Close
          </button>

          {brief && (
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 px-3 py-2 rounded-lg flex items-center gap-1 transition-colors"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{copied ? 'Copied' : 'Copy Brief'}</span>
              </button>
              <button
                onClick={handleMarkScheduled}
                className="flex items-center gap-2 bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold px-4 py-2 rounded-lg shadow-sm transition-colors cursor-pointer"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Mark P2P Scheduled & Save</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
